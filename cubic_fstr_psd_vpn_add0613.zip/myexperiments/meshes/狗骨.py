#  python3 ../myexperiments/meshes/狗骨.py

import numpy as np
from scipy.spatial import Delaunay
from collections import defaultdict

def generate_dogbone_cylinder_mesh(n_vertices=1000, length_to_diameter_ratio=4.0):
    """生成长径比4:1的狗骨形圆柱体四面体网格
    
    参数:
        n_vertices: 顶点数量
        length_to_diameter_ratio: 长径比（长度:直径），默认为4:1
    """
    
    np.random.seed(42)
    vertices = []
    
    # 狗骨形圆柱体参数
    # 总长度 L，直径 D，长径比 L:D = 4:1，所以 D = L/4
    # 设总长度 L = 4.0，则直径 D = 1.0
    total_length = 4.0
    diameter = total_length / length_to_diameter_ratio  # = 1.0
    radius = diameter / 2  # = 0.5
    
    # 两端球状凸起半径（比中间略大，形成狗骨特征）
    end_radius = radius * 1.3  # 端部半径0.65
    end_length = total_length * 0.3  # 端部长度1.2
    middle_radius = radius * 0.7  # 中间收缩半径0.35
    middle_length = total_length * 0.4  # 中间长度1.6
    
    # 坐标范围：-total_length/2 到 total_length/2
    half_length = total_length / 2
    
    # 分配点数：左端15%，右端15%，中间过渡区40%，内部30%
    n_left_end = int(n_vertices * 0.15)
    n_right_end = int(n_vertices * 0.15)
    n_transition = int(n_vertices * 0.40)
    n_interior = n_vertices - n_left_end - n_right_end - n_transition
    
    # 1. 左端部（球状凸起）
    left_center = np.array([-half_length + end_length/2, 0, 0])
    for _ in range(n_left_end):
        # 椭球状分布（在X方向拉长）
        u = np.random.uniform(0, 1)
        v = np.random.uniform(0, 1)
        w = np.random.uniform(0, 1)
        
        # 在椭球内部分布点
        theta = 2 * np.pi * u
        phi = np.arccos(2 * v - 1)
        r = end_radius * w ** (1/3)
        
        x_local = r * np.sin(phi) * np.cos(theta)
        y_local = r * np.sin(phi) * np.sin(theta) * 0.8  # 略微扁平
        z_local = r * np.cos(phi) * 0.8
        
        # X方向拉伸，使端部更饱满
        x_local = x_local * 1.2
        
        vertex = left_center + np.array([x_local, y_local, z_local])
        vertices.append(vertex)
    
    # 2. 右端部（球状凸起）
    right_center = np.array([half_length - end_length/2, 0, 0])
    for _ in range(n_right_end):
        u = np.random.uniform(0, 1)
        v = np.random.uniform(0, 1)
        w = np.random.uniform(0, 1)
        
        theta = 2 * np.pi * u
        phi = np.arccos(2 * v - 1)
        r = end_radius * w ** (1/3)
        
        x_local = r * np.sin(phi) * np.cos(theta)
        y_local = r * np.sin(phi) * np.sin(theta) * 0.8
        z_local = r * np.cos(phi) * 0.8
        x_local = x_local * 1.2
        
        vertex = right_center + np.array([x_local, y_local, z_local])
        vertices.append(vertex)
    
    # 3. 中间过渡区域（从端部向中间收缩）
    for _ in range(n_transition):
        # X坐标：从 -half_length+end_length 到 half_length-end_length
        x = np.random.uniform(-half_length + end_length, half_length - end_length)
        
        # 计算该位置的半径（狗骨形曲线）
        # 从端部到中间半径逐渐减小
        t = abs(x) / (half_length - end_length)  # 0在端部附近，1在中间
        # 使用余弦曲线平滑过渡
        local_radius = middle_radius + (end_radius - middle_radius) * (1 - t**2)
        
        # 圆柱坐标
        theta = np.random.uniform(0, 2 * np.pi)
        r = local_radius * np.sqrt(np.random.uniform())
        
        y = r * np.cos(theta)
        z = r * np.sin(theta)
        
        vertices.append([x, y, z])
    
    # 4. 内部点（填充整个狗骨形状）
    for _ in range(n_interior):
        # 随机X坐标
        x = np.random.uniform(-half_length, half_length)
        
        # 计算该位置的半径
        abs_x = abs(x)
        if abs_x > half_length - end_length:
            # 端部区域
            t = (abs_x - (half_length - end_length)) / end_length
            # 椭球形状的半径
            local_radius = end_radius * np.sqrt(1 - t**2)
        else:
            # 中间区域
            t = abs_x / (half_length - end_length)
            local_radius = middle_radius + (end_radius - middle_radius) * (1 - t**2)
        
        # 圆柱坐标内部分布
        theta = np.random.uniform(0, 2 * np.pi)
        r = local_radius * np.sqrt(np.random.uniform())
        
        y = r * np.cos(theta)
        z = r * np.sin(theta)
        
        vertices.append([x, y, z])
    
    vertices = np.array(vertices)
    
    # 确保精确的顶点数
    if len(vertices) > n_vertices:
        vertices = vertices[:n_vertices]
    elif len(vertices) < n_vertices:
        # 补充点
        remaining = n_vertices - len(vertices)
        for _ in range(remaining):
            x = np.random.uniform(-half_length, half_length)
            abs_x = abs(x)
            if abs_x > half_length - end_length:
                t = (abs_x - (half_length - end_length)) / end_length
                local_radius = end_radius * np.sqrt(1 - t**2)
            else:
                t = abs_x / (half_length - end_length)
                local_radius = middle_radius + (end_radius - middle_radius) * (1 - t**2)
            
            theta = np.random.uniform(0, 2 * np.pi)
            r = local_radius * np.sqrt(np.random.uniform())
            y = r * np.cos(theta)
            z = r * np.sin(theta)
            vertices = np.vstack([vertices, [x, y, z]])
    
    # 添加微小噪声避免Delaunay退化
    vertices += np.random.normal(0, 0.005, vertices.shape)
    
    print("正在计算Delaunay三角剖分...")
    tri = Delaunay(vertices)
    tetrahedra = tri.simplices
    
    # 过滤退化四面体
    def tetra_volume(v0, v1, v2, v3):
        return abs(np.dot(v1 - v0, np.cross(v2 - v0, v3 - v0))) / 6.0
    
    valid_tets = []
    for tet in tetrahedra:
        vol = tetra_volume(vertices[tet[0]], vertices[tet[1]], 
                          vertices[tet[2]], vertices[tet[3]])
        if vol > 1e-8:
            valid_tets.append(tet)
    
    tetrahedra = np.array(valid_tets)
    
    # 提取表面三角形
    face_counter = defaultdict(int)
    
    for tet in tetrahedra:
        faces = [
            tuple(sorted([tet[0], tet[1], tet[2]])),
            tuple(sorted([tet[0], tet[1], tet[3]])),
            tuple(sorted([tet[0], tet[2], tet[3]])),
            tuple(sorted([tet[1], tet[2], tet[3]]))
        ]
        for face in faces:
            face_counter[face] += 1
    
    # 表面三角形（只出现一次的面）
    surface_triangles = [list(face) for face, count in face_counter.items() if count == 1]
    
    print(f"顶点数: {len(vertices)}")
    print(f"四面体数: {len(tetrahedra)}")
    print(f"表面三角形数: {len(surface_triangles)}")
    
    return vertices, tetrahedra, surface_triangles

def save_to_mesh_format(filename, vertices, tetrahedra, surface_triangles):
    """按照指定格式保存.mesh文件"""
    with open(filename, "w") as f:
        # 版本头
        f.write("MeshVersionFormatted 1\n")
        
        # 维度
        f.write("Dimension 3\n")
        
        # 顶点部分
        f.write("Vertices\n")
        f.write(f"{len(vertices)}\n")
        for i, vertex in enumerate(vertices):
            # 判断是否为边界点（表面点）
            x, y, z = vertex
            r_surface = np.sqrt(y**2 + z**2)
            
            # 计算该位置的理论半径
            half_length = 2.0  # 总长度4的一半
            end_length = 1.2   # 端部长度
            end_radius = 0.65  # 端部半径
            middle_radius = 0.35  # 中间半径
            
            abs_x = abs(x)
            if abs_x > half_length - end_length:
                t = (abs_x - (half_length - end_length)) / end_length
                theoretical_radius = end_radius * np.sqrt(max(0, 1 - t**2))
            else:
                t = abs_x / (half_length - end_length)
                theoretical_radius = middle_radius + (end_radius - middle_radius) * (1 - t**2)
            
            # 如果点在表面附近，标记为边界点
            is_boundary = abs(r_surface - theoretical_radius) < 0.03 or abs(abs(x) - half_length) < 0.05
            label = 1 if is_boundary else 0
            f.write(f"{vertex[0]:.10f} {vertex[1]:.10f} {vertex[2]:.10f} {label}\n")
        # f.write("\n")
        
        # 四面体部分
        f.write("Tetrahedra\n")
        f.write(f"{len(tetrahedra)}\n")
        for tet in tetrahedra:
            f.write(f"{tet[0]+1} {tet[1]+1} {tet[2]+1} {tet[3]+1} 1\n")
        f.write("\n")
        
        # 三角形部分
        f.write("Triangles\n")
        f.write(f"{len(surface_triangles)}\n")
        for tri in surface_triangles:
            f.write(f"{tri[0]+1} {tri[1]+1} {tri[2]+1} 1\n")
        # f.write("\n")
        
        # 结束标记
        f.write("Edges\n")
        f.write("0\n")
        f.write("End\n")

# 生成狗骨形圆柱体网格
print("=" * 60)
print("生成狗骨形圆柱体四面体网格（长径比4:1）")
print("=" * 60)

vertices, tetrahedra, surface_triangles = generate_dogbone_cylinder_mesh(
    n_vertices=300, 
    length_to_diameter_ratio=4.0
)

# 保存文件
filename = "../data/dogbone_cylinder_v300_4to1.mesh"
save_to_mesh_format(filename, vertices, tetrahedra, surface_triangles)

print("\n" + "=" * 60)
print(f"✓ 网格已保存: {filename}")
print("=" * 60)
print(f"顶点数: {len(vertices)}")
print(f"四面体数: {len(tetrahedra)}")
print(f"表面三角形数: {len(surface_triangles)}")
print(f"\n狗骨形圆柱尺寸:")
print(f"  总长度: 4.0")
print(f"  最大直径: 1.3 (端部)")
print(f"  最小直径: 0.7 (中间收缩处)")
print(f"  长径比 (总长:端部直径): 4:1")
print(f"\n坐标范围:")
print(f"  X: [{np.min(vertices[:,0]):.3f}, {np.max(vertices[:,0]):.3f}]")
print(f"  Y: [{np.min(vertices[:,1]):.3f}, {np.max(vertices[:,1]):.3f}]")
print(f"  Z: [{np.min(vertices[:,2]):.3f}, {np.max(vertices[:,2]):.3f}]")

# 文件预览
print("\n文件预览（前20行）:")
print("-" * 60)
with open(filename, 'r') as f:
    for i, line in enumerate(f):
        if i < 20:
            print(f"{line.rstrip()}")
        else:
            print(f"... (共{i}行)")
            break

# 同时生成VTK文件便于可视化
def save_vtk_simple(filename, vertices, tetrahedra):
    with open(filename, 'w') as f:
        f.write("# vtk DataFile Version 3.0\n")
        f.write("Dogbone Cylinder Mesh (4:1 aspect ratio)\n")
        f.write("ASCII\n")
        f.write("DATASET UNSTRUCTURED_GRID\n")
        f.write(f"POINTS {len(vertices)} float\n")
        for v in vertices:
            f.write(f"{v[0]} {v[1]} {v[2]}\n")
        f.write(f"\nCELLS {len(tetrahedra)} {len(tetrahedra) * 5}\n")
        for tet in tetrahedra:
            f.write(f"4 {tet[0]} {tet[1]} {tet[2]} {tet[3]}\n")
        f.write(f"\nCELL_TYPES {len(tetrahedra)}\n")
        for _ in tetrahedra:
            f.write("10\n")

save_vtk_simple("dogbone_cylinder_4to1.vtk", vertices, tetrahedra)
print("\n同时生成了VTK文件: dogbone_cylinder_4to1.vtk")