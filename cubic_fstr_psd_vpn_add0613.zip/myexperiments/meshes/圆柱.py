
# python3 ../myexperiments/meshes/圆柱.py

import numpy as np
# import scipy.spatial
from scipy.spatial import Delaunay
from collections import defaultdict

import numpy as np
from scipy.spatial import Delaunay
from collections import defaultdict

def generate_short_cylinder_mesh(n_vertices=1000, diameter=2.0, height=1.0):
    """生成长径比2:1的矮圆柱体四面体网格
    
    参数:
        n_vertices: 顶点数量
        diameter: 圆柱直径（默认2.0）
        height: 圆柱高度（默认1.0，使长径比 = height:diameter = 1:2）
    
    长径比 = 高度:直径 = 1:2，即高度是直径的一半
    """
    
    np.random.seed(42)
    vertices = []
    
    radius = diameter / 2  # 半径 = 1.0
    half_height = height / 2  # 半高 = 0.5
    
    # 分配点数：底面15%，顶面15%，侧面40%，内部30%
    n_bottom = int(n_vertices * 0.15)
    n_top = int(n_vertices * 0.15)
    n_side = int(n_vertices * 0.40)
    n_interior = n_vertices - n_bottom - n_top - n_side
    
    # 1. 底面点 (z = -half_height)
    for _ in range(n_bottom):
        r = radius * np.sqrt(np.random.uniform())
        theta = np.random.uniform(0, 2 * np.pi)
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        vertices.append([x, y, -half_height])
    
    # 2. 顶面点 (z = half_height)
    for _ in range(n_top):
        r = radius * np.sqrt(np.random.uniform())
        theta = np.random.uniform(0, 2 * np.pi)
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        vertices.append([x, y, half_height])
    
    # 3. 侧面点（圆柱面）
    for _ in range(n_side):
        theta = np.random.uniform(0, 2 * np.pi)
        z = np.random.uniform(-half_height, half_height)
        x = radius * np.cos(theta)
        y = radius * np.sin(theta)
        vertices.append([x, y, z])
    
    # 4. 内部点
    for _ in range(n_interior):
        r = radius * np.sqrt(np.random.uniform())
        theta = np.random.uniform(0, 2 * np.pi)
        z = np.random.uniform(-half_height, half_height)
        x = r * np.cos(theta)
        y = r * np.sin(theta)
        vertices.append([x, y, z])
    
    vertices = np.array(vertices)
    
    # 确保精确的顶点数
    if len(vertices) > n_vertices:
        vertices = vertices[:n_vertices]
    elif len(vertices) < n_vertices:
        remaining = n_vertices - len(vertices)
        for _ in range(remaining):
            r = radius * np.sqrt(np.random.uniform())
            theta = np.random.uniform(0, 2 * np.pi)
            z = np.random.uniform(-half_height, half_height)
            x = r * np.cos(theta)
            y = r * np.sin(theta)
            vertices = np.vstack([vertices, [x, y, z]])
    
    # 添加微小噪声避免Delaunay退化
    vertices += np.random.normal(0, 0.003, vertices.shape)
    
    print("正在计算Delaunay三角剖分...")
    tri = Delaunay(vertices)
    tetrahedra = tri.simplices
    
    # 过滤退化四面体
    def tetra_volume(v0, v1, v2, v3):
        return abs(np.dot(v1 - v0, np.cross(v2 - v0, v3 - v0))) / 6.0
    
    valid_tets = []
    for tet in tetrahedra:
        vol = tetra_volume(vertices[tet[0]], vertices[tet[1]], 
                          vertices[tet[2]], vertices[tet[3]])
        if vol > 1e-8:
            valid_tets.append(tet)
    
    tetrahedra = np.array(valid_tets)
    
    # 提取表面三角形
    face_counter = defaultdict(int)
    
    for tet in tetrahedra:
        faces = [
            tuple(sorted([tet[0], tet[1], tet[2]])),
            tuple(sorted([tet[0], tet[1], tet[3]])),
            tuple(sorted([tet[0], tet[2], tet[3]])),
            tuple(sorted([tet[1], tet[2], tet[3]]))
        ]
        for face in faces:
            face_counter[face] += 1
    
    # 表面三角形（只出现一次的面）
    surface_triangles = [list(face) for face, count in face_counter.items() if count == 1]
    
    print(f"顶点数: {len(vertices)}")
    print(f"四面体数: {len(tetrahedra)}")
    print(f"表面三角形数: {len(surface_triangles)}")
    
    return vertices, tetrahedra, surface_triangles

def save_to_mesh_format(filename, vertices, tetrahedra, surface_triangles):
    """按照指定格式保存.mesh文件"""
    with open(filename, "w") as f:
        # 版本头
        f.write("MeshVersionFormatted 1\n")
        
        
        # 维度
        f.write("Dimension 3\n")
        
        
        # 顶点部分
        f.write("Vertices\n")
        f.write(f"{len(vertices)}\n")
        for vertex in vertices:
            # 判断是否为边界点
            r = np.sqrt(vertex[0]**2 + vertex[1]**2)
            is_boundary = (abs(r - 1.0) < 0.02) or (abs(abs(vertex[2]) - 0.5) < 0.02)
            label = 1 if is_boundary else 0
            f.write(f"{vertex[0]:.10f} {vertex[1]:.10f} {vertex[2]:.10f} {label}\n")
        # f.write("\n")
        
        # 四面体部分
        f.write("Tetrahedra\n")
        f.write(f"{len(tetrahedra)}\n")
        for tet in tetrahedra:
            f.write(f"{tet[0]+1} {tet[1]+1} {tet[2]+1} {tet[3]+1} 1\n")
        # f.write("\n")
        
        # 三角形部分
        f.write("Triangles\n")
        f.write(f"{len(surface_triangles)}\n")
        for tri in surface_triangles:
            f.write(f"{tri[0]+1} {tri[1]+1} {tri[2]+1} 1\n")
        # f.write("\n")
        
        # 结束标记
        f.write("Edges\n")
        f.write("0\n")
        f.write("End\n")

# 生成矮圆柱体网格
print("=" * 60)
print("生成矮圆柱体四面体网格（长径比2:1）")
print("=" * 60)

# 直径 = 2.0，高度 = 1.0，长径比 = 高度:直径 = 1:2 = 0.5
diameter = 2.0
height = 1.0
aspect_ratio = height / diameter  # = 0.5

vertices, tetrahedra, surface_triangles = generate_short_cylinder_mesh(
    n_vertices=300,
    diameter=diameter,
    height=height
)

# 保存文件
filename = "../data/short_cylinder_v300_aspect2to1.mesh"
save_to_mesh_format(filename, vertices, tetrahedra, surface_triangles)

print("\n" + "=" * 60)
print(f"✓ 网格已保存: {filename}")
print("=" * 60)
print(f"顶点数: {len(vertices)}")
print(f"四面体数: {len(tetrahedra)}")
print(f"表面三角形数: {len(surface_triangles)}")
print(f"\n圆柱尺寸:")
print(f"  直径: {diameter}")
print(f"  高度: {height}")
print(f"  半径: {diameter/2}")
print(f"  长径比 (高度:直径): {height}:{diameter} = 1:2")
print(f"\n坐标范围:")
print(f"  X: [{np.min(vertices[:,0]):.3f}, {np.max(vertices[:,0]):.3f}]")
print(f"  Y: [{np.min(vertices[:,1]):.3f}, {np.max(vertices[:,1]):.3f}]")
print(f"  Z: [{np.min(vertices[:,2]):.3f}, {np.max(vertices[:,2]):.3f}]")

# 计算实际长径比验证
actual_height = np.max(vertices[:,2]) - np.min(vertices[:,2])
actual_diameter = max(np.max(vertices[:,0]) - np.min(vertices[:,0]), 
                      np.max(vertices[:,1]) - np.min(vertices[:,1]))
actual_aspect = actual_height / actual_diameter
print(f"\n实际测量:")
print(f"  实际高度: {actual_height:.3f}")
print(f"  实际直径: {actual_diameter:.3f}")
print(f"  实际长径比: {actual_aspect:.3f} (理论值: 0.5)")

# 文件预览
print("\n文件预览（前20行）:")
print("-" * 60)
with open(filename, 'r') as f:
    for i, line in enumerate(f):
        if i < 20:
            print(f"{line.rstrip()}")
        else:
            print(f"... (共{i+1}行)")
            break

# 同时生成VTK文件便于可视化
def save_vtk_simple(filename, vertices, tetrahedra):
    with open(filename, 'w') as f:
        f.write("# vtk DataFile Version 3.0\n")
        f.write("Short Cylinder Mesh (Aspect Ratio 2:1)\n")
        f.write("ASCII\n")
        f.write("DATASET UNSTRUCTURED_GRID\n")
        f.write(f"POINTS {len(vertices)} float\n")
        for v in vertices:
            f.write(f"{v[0]} {v[1]} {v[2]}\n")
        f.write(f"\nCELLS {len(tetrahedra)} {len(tetrahedra) * 5}\n")
        for tet in tetrahedra:
            f.write(f"4 {tet[0]} {tet[1]} {tet[2]} {tet[3]}\n")
        f.write(f"\nCELL_TYPES {len(tetrahedra)}\n")
        for _ in tetrahedra:
            f.write("10\n")

save_vtk_simple("../data/short_cylinder_aspect2to1.vtk", vertices, tetrahedra)
print("\n同时生成了VTK文件: short_cylinder_aspect2to1.vtk")

# 生成圆柱体表面点云用于验证
print("\n生成表面点云文件...")
surface_points = []
for v in vertices:
    r = np.sqrt(v[0]**2 + v[1]**2)
    if abs(r - 1.0) < 0.02 or abs(abs(v[2]) - 0.5) < 0.02:
        surface_points.append(v)

with open("../data/short_cylinder_surface.xyz", "w") as f:
    for p in surface_points:
        f.write(f"{p[0]} {p[1]} {p[2]}\n")
print(f"表面点已保存: short_cylinder_surface.xyz ({len(surface_points)}个点)")
