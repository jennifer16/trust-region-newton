# 当前目录是 ~/Documents/fstr_psd/trust-region-newton/build
# python3 ../myexperiments/toys/all_deform.py

import sys, os

pre_str = 'python3 ../myexperiments/toys/'

# mesh_names = ['bar_1K' ]
mesh_names = {
   'stretch.py': ['bar_1K'],  # ['cyl248']
   # 'compress_percentage.py': ['bar_1K'], # ['cyl248','quad_2tets_3l']
   'compress_percentage.py': ['bar_1K'], # ['cyl248','quad_4tets_3l','tri_prism_3l']
   # 'compress.py': ['bar_1K'], # ['cyl248']
   'twist.py': ['cube'], # ['cyl248']
   'bend.py': ['bar_1K'],
   'shear_percentage.py': ['cube'],
}

#diff_constraint = True  #

# commands = ['bend.py', 'compress.py','shear.py', 'stretch.py', 'twist.py','combined.py']
# commands = ['compress.py', 'bend.py','stretch.py', 'twist.py','shear.py']
# diff_mode_strs = ['clamp_abs_blending_shear','clamp_abs_blending','clamp_abs_nondiff']

# commands = ['compress.py']
# diff_mode_strs = ['clamp_abs_blending']


# commands = [ 'bend.py', 'compress_percentage.py','shear_percentage.py','stretch.py','twist.py']
# commands = [ 'shear.py','bend.py', 'twist.py','compress.py','stretch.py']
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending']
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending','clamp_abs_blending2','clamp_abs_blending_smooth']


# commands = ['stretch.py',  'compress_percentage.py', 'bend.py','shear_percentage.py','twist.py']
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending','clamp_abs_blending3','clamp_abs_blending4','clamp_abs_blending5']

# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending']

# commands = ['stretch.py',  'compress_percentage.py', 'bend.py','shear_percentage.py','twist.py']

commands = ['compress_percentage.py']
diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending']

# commands = ['compress_percentage.py']
# diff_mode_strs = ['clamp_nondiff']


# pr_list = ['0.495','0.49','0.45','0.4','0.3']
pr_list = ['0.495']
# pr_list = ['0.495','0.3']
ym_list = ['1e8']
adaptive = '1'  # <= 0:[0 / 1] ; >0：[0 to 1]

for com in commands:
    os.system(pre_str+com+ ' --methods ' + ','.join(diff_mode_strs) + ' --meshes ' + ','.join(mesh_names[com]) + ' --pr ' + ','.join(pr_list) + ' --ym ' + ','.join(ym_list) + ' --adaptive ' + adaptive)