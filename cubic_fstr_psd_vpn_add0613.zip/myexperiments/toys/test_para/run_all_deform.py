# python3 ../myexperiments/toys/run_all_deform.py


import sys, os
import glob

cwd = os.getcwd()

pre_str = "../myexperiments/toys/"
#baseline
# pass: pythonFileList = ['all_deform1.py']
# ===>pass: grad_mode 0&1 are better than 4, diff safe & unsafe is good.
# pythonFileList = ['all_deform2.py','all_deform3.py','all_deform4.py'] 

# ===>pass: grad_mode 2 or 3 is better than 0/1/4, with alpha_min(eta_mode = 0)
# pythonFileList = ['all_deform5.py','all_deform6.py'] 

# ===>pass: gamma_mode, -11,-12, -1,-2/-11,-2,-1, 4g^2/h^3 (-11)> f/h^3(2)
# pythonFileList = ['all_deform7.py'] 


# ===>pass: energy-grad_mode(5,6,7,8), exact element energy /avg energy, 2,3 fast > 5,6stable > 7,8
# pythonFileList = ['all_deform8.py'] 

# ===>?: update_gamma(0,2,1)&eta&kappa,local gamma(j/mu)/fixed 
pythonFileList = ['all_deform10.py'] # ,'all_deform2.py','all_deform3.py'

# ===>?: eta
# pythonFileList = ['all_deform10.py'] 

for file in pythonFileList:
  print("Running: " + pre_str + file)
  os.system('python3 ' + pre_str + file)