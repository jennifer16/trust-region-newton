# 当前目录是 ~/Documents/fstr_psd/trust-region-newton/build
# python3 ../myexperiments/analysis/process_csv.py

import pandas as pd
import numpy as np


filename = 'results_compare_0426'
filedir =  '../myexperiments/analysis/'
inputfilepath = filedir + filename
inputfilename = inputfilepath + '.csv'

outputfilepath = filedir + 'output/'  
outputfilename_energy = outputfilepath + '_energy'
outputfilename_line_search_iter = outputfilepath + '_line_search_iter'
outputfilename_energy_injection = outputfilepath + '_energy_injection'
outputfilename_energy_descrease = outputfilepath + '_energy_descrease'

mode = []
filename_suffix = ['_energy.csv','_line_search_iter.csv','_energy_injection.csv','_energy_descrease.csv']

def split_df(df, coli):
    unique_values = df.iloc[:,coli].unique()

    # 拆分为多个 DataFrame
    split_dfs = {}
    for value in unique_values:
        split_dfs[value] = df[df.iloc[:,coli] ==  value]
        # print(f"值 {value}: 行数 = {split_dfs[value].shape[0]}")


    return split_dfs


def read_n_cols(df, colstarts, cols_per_row):
    # 存储结果
    df_energy_cols = []

    for (idx1, val1), (idx2, val2) in zip(colstarts.items(), cols_per_row.items()):
        if (pd.isna(val1) or  pd.isna(val2) ):
            val1 = 12
            val2 = 0
        val1 = int(val1)
        val2 = int(val2)
        
        row_data = df.iloc[idx1, val1:(val1 + val2)].tolist()
        df_energy_cols.append(row_data)

    return df_energy_cols



def process_mode(mode, df_split) :   
    # ======= 提取列 =======
    # 提取前12列
    df_12cols = df_split.iloc[0:, :12] # 第12行

    colstart = pd.DataFrame(np.zeros((len(df_split), 1),dtype=int), columns=['colstart'])
    
    # 提取enregy 
    colstart = colstart['colstart'] + 12
    cols_per_row =  df_12cols.iloc[:,-1]

    df_energycols = read_n_cols(df_split, colstart, cols_per_row + 1)
    df_write = df_12cols
    df_write['energy'] = df_energycols

    # 提取linear search iter 
    colstart = pd.Series(colstart.values + cols_per_row.values)
    
    df_line_search_iter_cols = read_n_cols(df_split, colstart + 1, cols_per_row )
    df_write['line_search_iter'] = df_line_search_iter_cols

    # 提取energy_injection
    colstart = pd.Series(colstart.values + cols_per_row.values)
    
    df_energy_injection_cols = read_n_cols(df_split, colstart + 1, cols_per_row-1)
    df_write['energy_injection'] = df_energy_injection_cols

    # # 提取energy_descrease
    colstart = pd.Series(colstart.values + cols_per_row.values)
    
    df_energy_descrease_cols = read_n_cols(df_split, colstart + 1, cols_per_row)
    df_write['energy_descrease'] = df_energy_descrease_cols

    # # ======= 写入 4个 CSV =======
    df_selected = df_write.iloc[:, [*range(12), 12]]
    # print(f"选择的列: {list(df_selected.columns)}")
    df_selected.to_csv(outputfilepath + filename+'_'+mode + filename_suffix[0], index=False, encoding='utf-8-sig')

    df_selected = df_write.iloc[:, [*range(12), 13]]
    # print(f"选择的列: {list(df_selected.columns)}")
    df_selected.to_csv(outputfilepath + filename+'_' + mode + filename_suffix[1], index=False, encoding='utf-8-sig')

    df_selected = df_write.iloc[:, [*range(12), 14]]
    # print(f"选择的列: {list(df_selected.columns)}")
    df_selected.to_csv(outputfilepath + filename+'_'+ mode + filename_suffix[2], index=False, encoding='utf-8-sig')

    df_selected = df_write.iloc[:, [*range(12), 15]]
    # print(f"选择的列: {list(df_selected.columns)}")
    df_selected.to_csv(outputfilepath + filename+'_'+ mode + filename_suffix[3], index=False, encoding='utf-8-sig')

# ======= 读取csv =======
df_read = pd.read_csv(inputfilename)

df_splitted = split_df(df_read,4) # 按arr_pos分组
# print(df_splitted.keys())

for mode in df_splitted.keys():
    print(mode, df_splitted[mode].shape[0], df_splitted[mode].shape[1])
    process_mode(mode, df_splitted[mode])