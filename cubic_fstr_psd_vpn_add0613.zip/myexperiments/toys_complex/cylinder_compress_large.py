#  python3 ../myexperiments/toys_complex/cylinder_compress_large.py
import os
import sys

# 获取命令行参数
# sys.argv[0] 是脚本名称，sys.argv[1:] 是实际参数
args = sys.argv[1:]

# 1.methods
if len(args)>=2 and args[0] == '--methods':  
    diff_mode_strs = args[1].split(',') 
else:
    diff_mode_strs = ['clamp_abs_blending'] 
print(f"方法: {diff_mode_strs}")

# 2.mesh_names
if len(args)>=4 and args[2] == '--meshes':  
    mesh_names = args[3].split(',')
else:
    mesh_names = ['cylinder' ]
print(f"模型: {mesh_names}")

# 3.ym
if len(args)>=6 and args[4] == '--ym':  
    ym_list = args[5].split(',')
else:
    ym_list = ['1e8']
print(f"ym: {ym_list}")

# 4.adaptive
if len(args)>=8 and args[6] == '--adaptive':  
    adaptive = args[7]
else:
    adaptive = '-1'
print(f"adaptive: {adaptive}")

# mesh_names = ['octopus_4K','bunny_6K','squirrel_7K','bar_1K','bar_2K','bar_4K','cube_3K', 'longbar_1.6K','cube_3K']
# mesh_names = ['bar_1K' ]

smooth_mode_strs = ["none"] # ["face","none"] ["none","face", "default"]
diff = True #只要带这个选项就为true
proj_eps = '1e-7'

# proj_eps_list = ['-1', '0', '-0.5']
pr_list = ['0.495']
deform_scale_list = ['0.5']

mesh_name = 'cylinder'
experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
  # for proj_eps in proj_eps_list:
    for pr in pr_list:
      for deform_scale in deform_scale_list:
        try:
          command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
            + ' -l compress_longest_axis -t ' + deform_scale \
            + ' --ym 1e8 --pr ' + pr \
            + ' --experiment_name ' + experiment_name \
            + ' --diff' \
            + ' --diff_mode ' + diff_mode_str \
            + ' --smooth_mode ' + smooth_mode_str \
            + ' --adaptive ' + adaptive \
            + ' --tr 0.1' 
          print(command)
          os.system(command)
        except:
          print('Error: ' + mesh_name)
