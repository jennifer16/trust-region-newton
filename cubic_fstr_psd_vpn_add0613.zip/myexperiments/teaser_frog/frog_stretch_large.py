# python3 ../myexperiments/teaser_frog/frog_stretch_large.py

import os

smooth_mode_strs = ["face","none"] # ["none","face", "default"]
diff = True
diff_mode_strs = ['abs_nondiff'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs '] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'

# proj_eps_list = ['-0.5', '-1', '0']
# pr_list = ['0.495', '0.3']
pr_list = ['0.495']

deform_scale = '-1.5'
deform_label = 'stretch_shear_front2'

mesh_name = 'frog'
experiment_name = 'figure_' + os.path.basename(__file__)[:-3]
diff = True

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
    for pr in pr_list:
      # for proj_eps in proj_eps_list:
        try:
          command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
            + ' -l ' + deform_label + ' -g ' + deform_scale \
            + ' --ym 1e8 --pr ' + pr \
            + ' --experiment_name ' + experiment_name \
            + ' --tr 0.01' \
            + ' --diff' \
            + ' --diff_mode ' + diff_mode_str \
            + ' --smooth_mode ' + smooth_mode_str \
            + ' -b 0.2'
          print(command)
          os.system(command)
        except:
          print('Error: ' + mesh_name)