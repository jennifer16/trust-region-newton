# python3 ../myexperiments/analysis/plot_table_pics.py

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from matplotlib.ticker import LogLocator, FuncFormatter
import matplotlib.font_manager as fm
import os
import re
import math




# 配置文件路径
files = ['bend_bar_final.csv','twist_bar_final.csv','stretch_bar_final.csv','shear_bar_final.csv','compress_cylinder_final.csv']

# files = ['bend_bar_final.csv','twist_bar_final.csv','stretch_bar_final.csv','shear_bar_final.csv']
files = ['bend_bar_final.csv']

data_dir = '../myexperiments/analysis/'
output_dir = '../myexperiments/analysis/output/'  # 输出目录

paras = {'bend':[0.1,0.25,0.4, 0.5,0.6, 0.75, 0.8, 0.9,1.0], 
'twist':['0.1','0.25','0.4', '0.5','0.6', '0.75', '0.8'],
'compress':['0.1','0.2', '0.3', '0.4', '0.5', '0.6', '0.7', '0.8'],
'stretch':['1.0','1.5','2.0','2.5','3.0'],
'shear':['0.3','0.5','0.8','1.0','1.5', '2.0']
}

experiment_set_cols = {'bend':'rotate_ratio', 
'twist':'rotate_ratio',
'compress':'deformation_ratio',
'stretch':'deformation_ratio',
'shear':'deformation_ratio'
}
# rotate_ratio列表
# rotate_ratios = [0.1, 0.4, 0.75, 1.0]
# pr_vals = [0.495,0.3]
pr_vals = [0.495]
debug = False

# 算法配置（CSV中的方法名）
algorithms = ['clamp_nondiff', 'abs_nondiff', 'clamp_abs_nondiff', 'clamp_abs_blending']
algorithm_labels = ['Clamp', 'Abs', 'Trust-region', 'Proposed']

# 图形样式配置:虚线 vs 实线
colors = ['#777777', '#777777', '#777777', '#000000']
line_styles = [':', '--', ':', '-']  # 点线:、虚线--、点划线'-.'、实线- 
line_widths = [2.0, 2.0, 2.0, 3.5]
markers = ['o', '^', 'v', 's']
marker_sizes = [7, 7, 7, 7]
markerfacecolors = ['#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF']

# # 图形样式配置:还不错
# colors = ['#000000', '#444444', '#777777', '#000000']
# line_styles = [':', '--', '-.', '-']  # 点线:、虚线--、点划线'-.'、实线- 
# line_widths = [1.5, 1.5, 1.5, 2.5]
# markers = ['o', 's', '^', 'd']
# marker_sizes = [, 6, 6, 9]
# markerfacecolors = ['#000000','#444444','#777777','#000000']

# # 图形样式配置:实心填充更突出
# colors = ['#777777', '#777777', '#777777', '#000000']
# line_styles = [':', ':', ':', '-']  # 点线:、虚线--、点划线'-.'、实线- 
# line_widths = [1.5, 1.5, 1.5, 2.5]
# markers = ['o', '^', 'v', 's']
# marker_sizes = [6, 6, 6, 6]
# markerfacecolors = ['#FFFFFF','#FFFFFF','#FFFFFF','#FFFFFF']

# # 图形样式配置: 线型太杂了
# colors = ['#111111', '#111111', '#111111', '#000000']
# line_styles = [':', '--', '-.', '-']  # 点线:、虚线--、点划线'-.'、实线- 
# line_widths = [1.5, 1.5, 1.5, 2.5]
# markers = ['o', '^', 'v', 's']
# marker_sizes = [6, 6, 6, 6]
# markerfacecolors = ['#FFFFFF','#FFFFFF','#FFFFFF','#000000']

# 1. 下载Times New Roman字体文件到AI Studio
# 方法：在AI Studio中创建font文件夹，上传TimesNewRoman.ttf文件
font_path = 'font/TimesNewRoman.ttf'  # 根据实际路径调整

# # 2. 检查字体文件是否存在
# if os.path.exists(font_path):
#     # 添加字体到matplotlib
#     fm.fontManager.addfont(font_path)
#     plt.rcParams['font.family'] = 'serif'
#     plt.rcParams['font.serif'] = ['Times New Roman']
#     print("Times New Roman 字体加载成功")
# else:
#     print("字体文件不存在，使用默认字体")

# 3. 或者使用FontProperties对象指定字体
from matplotlib.font_manager import FontProperties
times_font = FontProperties(fname=font_path, size=12)


# 设置中文字体和Times New Roman（适合专利申请）
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.family'] = 'Times New Roman'
# plt.rcParams['font.family'] = 'serif'
# plt.rcParams['font.serif'] = ['Times New Roman']
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['axes.unicode_minus'] = False

truncate_iter = 20


def generate_table(data, rotate_ratios, algorithms, algorithm_labels, pr_val,name, output_csv=None):
    """生成迭代次数对比表格并保存为CSV"""
    
    # 创建DataFrame
    table_data = []
    for rr in rotate_ratios:
        row = {'rotate_ratio': rr}
        for algo in algorithms:
            n_iter = data.get(algo, {}).get(rr, {}).get('n_iter', '-')
            row[algo] = n_iter
        table_data.append(row)
    
    df = pd.DataFrame(table_data)
    
    # 重命名列为显示名称
    df.columns = ['rotate_ratio'] + algorithm_labels
    
    # 保存为CSV文件
    if output_csv is None:
        output_csv = 'iteration_comparison_table.csv'
    
    df.to_csv(output_csv, index=False, encoding='utf-8-sig')
    print(f"表格已保存到: {output_csv}")
    
    # 同时打印到控制台
    print("\n" + "="*70)
    print(f"表1 四种算法迭代次数对比（pr={pr_val},{name}）")
    print("="*70)
    print(df.to_string(index=False))
    print("\n注：所有算法均在200次迭代内收敛")
    print("="*70)
    
    return df

# ==================== 打印数据结构（调试用） ====================
def print_data_structure(data):
    """打印数据结构以便调试"""
    print("\n数据结构:")
    for method in data:
        print(f"  {method}:")
        for rr in data[method]:
            n_iter = data[method][rr]['n_iter']
            energy_len = len(data[method][rr]['energy'])
            print(f"    rotate_ratio={rr}: n_iter={n_iter}, energy_len={energy_len}")
            if energy_len > 0:
                print(f"      前5个能量值: {data[method][rr]['energy'][:5]}")

def set_y_ticks_with_min_max(ax, y_min, y_max, num_ticks=5):
    """简洁版：设置Y轴刻度，包含最小值和最大值"""
    
    # 计算对数刻度
    log_min, log_max = math.log10(y_min), math.log10(y_max)
    ticks = [10 ** (log_min + i * (log_max - log_min) / (num_ticks - 1)) 
             for i in range(num_ticks)]
    
    # 确保精确包含边界值
    ticks[0] = y_min
    ticks[-1] = y_max

    # 设置刻度
    ax.set_yticks(ticks)
    ax.set_yticklabels([f'{t:.1e}' for t in ticks])
    
    

# ==================== 生成收敛曲线图 ====================
def create_convergence_chart(data, rotate_ratio, algorithms, algorithm_labels, colors, line_styles, line_widths, markers, marker_sizes, markerfacecolors,output_path=None):
    """生成单张收敛曲线图"""
    fig, ax = plt.subplots(figsize=(8.5, 4.5))
    
    for i, algo in enumerate(algorithms):
        if algo not in data or rotate_ratio not in data[algo]:
            continue
        
        energy = data[algo][rotate_ratio]['energy']
        if len(energy) == 0:
            continue
            
        iterations = range(1, len(energy) + 1)
        
        # 只显示前30次迭代
        if len(energy) > truncate_iter:
            energy = energy[:truncate_iter]
            iterations = range(1, len(energy) + 1)
        
        ax.plot(iterations, energy, 
                color=colors[i], 
                linestyle=line_styles[i], 
                linewidth=line_widths[i],
                marker=markers[i],
                markersize=marker_sizes[i],
                markerfacecolor = markerfacecolors[i],
                label=algorithm_labels[i],
                markevery=max(1, min(len(energy),truncate_iter)//10))
    
    # 设置坐标轴
    ax.set_xlabel('Iteration', fontsize=14, fontweight='bold')
    ax.set_ylabel('log10(Energy)', fontsize=14, fontweight='bold')
    

    # 设置Y轴为对数坐标
    ax.set_yscale('log')

    
    # 收集所有能量值用于设置Y轴范围
    all_energy = []
    for algo in algorithms:
        if algo in data and rotate_ratio in data[algo]:
            all_energy.extend(data[algo][rotate_ratio]['energy'][:truncate_iter])
    
    if all_energy:
        y_min = min(all_energy) * 0.8
        y_max = max(all_energy) * 1.2
        ax.set_ylim(y_min, y_max)

    # log_min, log_max = math.floor(math.log10(y_min)), math.ceil(math.log10(y_max))
    # ticks = [10 ** (log_min + i * (log_max - log_min) / 4) for i in range(5)]
    # ax.set_yticks(ticks)
    # ax.set_yticklabels([f'{t:.0e}' for t in ticks])
    # y_min = min(all_energy) / 1.2
    # y_max = max(all_energy) * 1.2
    set_y_ticks_with_min_max(ax, y_min, y_max, 5)

    # # ========== 方法二：自动生成10个对数刻度 ==========
    # # y_min, y_max = 5e6, 2e9
    # log_min = math.floor(math.log10(y_min))
    # log_max = math.ceil(math.log10(y_max))
    # log_ticks = [10**i for i in range(log_min, log_max + 1)]
    # ax.set_yticks(log_ticks)
    # ax.set_yticklabels([f'1e{i}' for i in range(log_min, log_max + 1)])

    # # ========== 方法三：使用LogLocator（推荐） ==========
    # ax.yaxis.set_major_locator(LogLocator(base=10, numticks=8))
    # ax.yaxis.set_major_formatter(FuncFormatter(lambda x, p: f'{x:.0e}'))
    
    # 设置网格
    ax.grid(True, linestyle='--', alpha=0.5, color='#cccccc')
    
    # 设置边框
    for spine in ax.spines.values():
        spine.set_linewidth(1.5)
        spine.set_color('black')
    
    # 图例（右上角）
    ax.legend(loc='upper right', frameon=True, fancybox=False, 
              edgecolor='black', fontsize=11, framealpha=0.9)
    
    # 设置刻度字体
    ax.tick_params(axis='both', labelsize=11, width=1.5, length=5)
    
    plt.tight_layout()
    
    if output_path:
        plt.savefig(output_path, dpi=600, bbox_inches='tight', facecolor='white')
        print(f"已保存: {output_path}")
    
    plt.close()
    return fig

# ==================== 生成所有图表 ====================
def generate_all_charts(data, rotate_ratios, algorithms, algorithm_labels, colors, line_styles, line_widths, markers, marker_sizes,markerfacecolors, name,output_dir='./'):
    """生成所有rotate_ratio对应的图表"""
    for rr in rotate_ratios:
        # 检查是否有数据
        has_data = False
        for algo in algorithms:
            if algo in data and rr in data[algo] and len(data[algo][rr]['energy']) > 0:
                has_data = True
                break
        
        if not has_data:
            print(f"警告：rotate_ratio={rr} 没有有效数据，跳过")
            continue
            
        output_path = f"{output_dir}convergence_{name}_{int(rr*10)}.png"
        create_convergence_chart(data, rr, algorithms, algorithm_labels, colors, 
                                 line_styles, line_widths, markers, marker_sizes,markerfacecolors, output_path)



# ==================== 读取CSV数据 ====================
def read_csv_data(filepath, pr_val,experiment_set_col):# ==================== 读取CSV数据 ====================
    """从CSV文件读取数据"""
    # 尝试不同的编码和分隔符
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        first_line = f.readline()
    
    # 检测分隔符（逗号或制表符）
    if '\t' in first_line:
        sep = '\t'
    else:
        sep = ','
    
    # 读取CSV
    df = pd.read_csv(filepath, sep=sep, encoding='utf-8-sig')
    
    # 清理列名（去除空格和特殊字符）
    df.columns = df.columns.str.strip()
    
    # print("可用列名:", df.columns.tolist())
    
    # 查找pr列（可能有不同名称）
    pr_col = None
    for col in df.columns:
        if 'pr' in col.lower():
            pr_col = col
            break
    
    if pr_col is None:
        print("警告：未找到pr列，使用所有数据")
    else:
        # print(f"使用pr列: {pr_col}")
        # 提取pr=0.495的数据
        df = df[df[pr_col] == pr_val]
    
    # 查找method列
    method_col = None
    for col in df.columns:
        if 'method' in col.lower():
            method_col = col
            break
    
    # 查找experimental setting列
    rotate_col = None
    for col in df.columns:
        if experiment_set_col in col.lower():
            rotate_col = col
            break

    if (not rotate_col):
        for col in df.columns:
            if 'deformation_ratio' in col.lower():
                rotate_col = col
                break

    # print('experiment_set_col:',experiment_set_col)
    print('rotate_col:',rotate_col)

    # 查找n_iter列
    n_iter_col = None
    for col in df.columns:
        if 'n_iter' in col.lower() or 'n_iter' in col:
            n_iter_col = col
            break
    
    # print(f"method列: {method_col}, rotate列: {rotate_col}, n_iter列: {n_iter_col}")
    
    # 提取数据
    data = {}
    for idx, row in df.iterrows():
        if method_col is None:
            continue
        
        method = row[method_col]
        
        # 获取rotate_ratio
        if rotate_col is not None:
            rotate_ratio = row[rotate_col]
        else:
            rotate_ratio = idx  # 使用索引作为fallback
        
        # 获取n_iter
        if n_iter_col is not None:
            n_iter = int(row[n_iter_col]) if pd.notna(row[n_iter_col]) else 0
        else:
            n_iter = 0
        
        # 提取能量序列（从第13列开始，跳过前面的元数据列）
        energy_values = []
        # 尝试找到能量值的起始位置（跳过前12列左右的元数据）
        start_col = 12  # 假设能量值从第13列开始
        end_col = row.iloc[start_col-1] + start_col
        # print('end_col:',end_col)
        for i in range(start_col, end_col):
            # print(i, row.iloc[i-1])
            val = row.iloc[i]
            if pd.notna(val) and val != 1 and val != 0:  # 跳过填充值1和0
                try:
                    energy_values.append(float(val))
                except (ValueError, TypeError):
                    pass
            elif len(energy_values) > 0 and (val == 1 or val == 0):
                break  # 遇到填充值停止
        
        # 如果没找到能量值，尝试从后面找
        if len(energy_values) == 0:
            for i in range(len(row)-1, -1, -1):
                val = row.iloc[i]
                if pd.notna(val) and val != 1 and val != 0:
                    try:
                        energy_values.insert(0, float(val))
                    except (ValueError, TypeError):
                        pass
                elif len(energy_values) > 0:
                    break
        
        if method not in data:
            data[method] = {}
        
        data[method][rotate_ratio] = {
            'n_iter': n_iter if n_iter > 0 else len(energy_values),
            'energy': energy_values
        }
    
    return data



# ==================== 主程序 ====================
def main():
    
    try:
        for csvfile in files:
            for pr_val in pr_vals:
            
                filepath = os.path.join(data_dir, csvfile)
                names = csvfile.split('_',1)
                print(names)
                if (len(names) > 0):
                    name = names[0]
                else:
                    name = names

                print(experiment_set_cols[name])
                # 读取数据
                data = read_csv_data(filepath, pr_val, experiment_set_cols[name])
                
                # 打印数据结构（调试用）
                if (debug):
                    print_data_structure(data)

                # 读取rotate_ratio
                rotate_ratios = paras[name]
                # print(paras[csvfile.split('_')[0]])
                
                # 生成表格
                table_csv_file = output_dir + name+'_pr_'+ str(pr_val)+'.csv'
                generate_table(data, rotate_ratios, algorithms, algorithm_labels, pr_val,name,table_csv_file )
                
                # 生成所有图表
                generate_all_charts(data, rotate_ratios, algorithms, algorithm_labels, colors, 
                                line_styles, line_widths, markers, marker_sizes, markerfacecolors,name+'_'+ str(pr_val), output_dir)
                
                print("\n所有图表生成完成！")
            
    except FileNotFoundError:
        print(f"错误：找不到文件 {filepath}")
    except Exception as e:
        print(f"错误：{e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()