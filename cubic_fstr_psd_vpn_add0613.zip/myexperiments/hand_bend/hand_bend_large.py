#  python3 ../myexperiments/hand_bend/hand_bend_large.py

import os

smooth_mode_strs = ["face","none"] # ["none","face", "default"]
diff = True
diff_mode_strs = ['abs_nondiff'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs '] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'

# proj_eps_list = ['-1', '0', '-0.5']
pr_list = ['0.48']
pr_list.reverse()

mesh_name = 'hand_closed'
experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
  # for proj_eps in proj_eps_list:
    for pr in pr_list:
      try:
        command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
          + ' -l bend_stretch -t 0.1' \
          + ' --ym 1e8 --pr ' + pr \
          + ' --experiment_name ' + experiment_name \
          + ' --tr 0.01' \
          + ' -c 4e-7' \
          + ' --diff' \
          + ' --diff_mode ' + diff_mode_str \
          + ' --smooth_mode ' + smooth_mode_str \
          + ' --rotate_ratio 0.5' 
        print(command)
        os.system(command)
      except:
        print('Error: ' + mesh_name)
