# python3 ../myexperiments/meshes/refine_mesh.py

import numpy as np
from collections import defaultdict
import copy

def read_mesh_file(filename):
    """读取.mesh文件，返回顶点、四面体、三角形数据"""
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    vertices = []
    tetrahedra = []
    triangles = []
    
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        
        if 'Vertices' in line:
            i += 1
            n_verts = int(lines[i].strip())
            i += 1
            for j in range(n_verts):
                coords = list(map(float, lines[i].split()[:3]))
                label = int(lines[i].split()[3]) if len(lines[i].split()) > 3 else 0
                vertices.append({'coords': np.array(coords), 'label': label})
                i += 1
        
        elif 'Tetrahedra' in line:
            i += 1
            n_tets = int(lines[i].strip())
            i += 1
            for j in range(n_tets):
                indices = list(map(int, lines[i].split()[:4]))
                label = int(lines[i].split()[4]) if len(lines[i].split()) > 4 else 1
                tetrahedra.append({'indices': [idx-1 for idx in indices], 'label': label})
                i += 1
        
        elif 'Triangles' in line:
            i += 1
            n_tris = int(lines[i].strip())
            i += 1
            for j in range(n_tris):
                indices = list(map(int, lines[i].split()[:3]))
                label = int(lines[i].split()[3]) if len(lines[i].split()) > 3 else 1
                triangles.append({'indices': [idx-1 for idx in indices], 'label': label})
                i += 1
        else:
            i += 1
    
    return vertices, tetrahedra, triangles

def write_mesh_file(filename, vertices, tetrahedra, triangles):
    """写入.mesh文件"""
    with open(filename, 'w') as f:
        f.write("MeshVersionFormatted 1\n")
        
        f.write("Dimension 3\n")
        
        # 写入顶点
        f.write("Vertices\n")
        f.write(f"{len(vertices)}\n")
        for v in vertices:
            f.write(f"{v['coords'][0]:.10f} {v['coords'][1]:.10f} {v['coords'][2]:.10f} {v['label']}\n")
        # f.write("\n")
        
        # 写入四面体
        f.write("Tetrahedra\n")
        f.write(f"{len(tetrahedra)}\n")
        for tet in tetrahedra:
            f.write(f"{tet['indices'][0]+1} {tet['indices'][1]+1} {tet['indices'][2]+1} {tet['indices'][3]+1} {tet['label']}\n")
        # f.write("\n")
        
        # 写入三角形
        if triangles:
            f.write("Triangles\n")
            f.write(f"{len(triangles)}\n")
            for tri in triangles:
                f.write(f"{tri['indices'][0]+1} {tri['indices'][1]+1} {tri['indices'][2]+1} {tri['label']}\n")
            # f.write("\n")
        
        f.write("Edges\n")
        f.write("0\n")
        f.write("End\n")

def refine_tetrahedron(tet, vertices, edge_midpoints, new_vertex_counter):
    """细化单个四面体为8个子四面体"""
    
    # 获取四面体的4个顶点索引
    v0, v1, v2, v3 = tet['indices']
    
    # 计算6条边的中点索引
    edges = [
        (v0, v1), (v0, v2), (v0, v3),
        (v1, v2), (v1, v3), (v2, v3)
    ]
    
    midpoints = []
    for edge in edges:
        key = tuple(sorted(edge))
        midpoints.append(edge_midpoints[key])
    
    m01, m02, m03, m12, m13, m23 = midpoints
    
    # 生成8个子四面体
    sub_tets = [
        # 角隅四面体
        {'indices': [v0, m01, m02, m03], 'label': tet['label']},
        {'indices': [v1, m01, m12, m13], 'label': tet['label']},
        {'indices': [v2, m02, m12, m23], 'label': tet['label']},
        {'indices': [v3, m03, m13, m23], 'label': tet['label']},
        # 中心四面体
        {'indices': [m01, m02, m03, m12], 'label': tet['label']},
        {'indices': [m01, m03, m12, m13], 'label': tet['label']},
        {'indices': [m02, m03, m12, m23], 'label': tet['label']},
        {'indices': [m01, m12, m13, m23], 'label': tet['label']}
    ]
    
    return sub_tets

def refine_surface_triangle(tri, vertices, edge_midpoints, new_vertex_counter):
    """细化表面三角形为4个子三角形"""
    
    v0, v1, v2 = tri['indices']
    
    # 计算3条边的中点索引
    edges = [(v0, v1), (v0, v2), (v1, v2)]
    
    midpoints = []
    for edge in edges:
        key = tuple(sorted(edge))
        midpoints.append(edge_midpoints[key])
    
    m01, m02, m12 = midpoints
    
    # 生成4个子三角形
    sub_tris = [
        {'indices': [v0, m01, m02], 'label': tri['label']},
        {'indices': [v1, m01, m12], 'label': tri['label']},
        {'indices': [v2, m02, m12], 'label': tri['label']},
        {'indices': [m01, m02, m12], 'label': tri['label']}
    ]
    
    return sub_tris

def refine_mesh(vertices, tetrahedra, triangles):
    """细化网格（每个四面体细分为8个，每个三角形细分为4个）"""
    
    print("开始网格细化...")
    
    # 创建顶点查找表
    vertex_dict = {i: v for i, v in enumerate(vertices)}
    
    # 收集所有需要细分的边
    edges = set()
    for tet in tetrahedra:
        indices = tet['indices']
        for i in range(4):
            for j in range(i+1, 4):
                edges.add(tuple(sorted([indices[i], indices[j]])))
    
    # 计算边的中点
    edge_midpoints = {}
    new_vertices = copy.deepcopy(vertices)
    next_vertex_id = len(vertices)
    
    for edge in edges:
        v0_idx, v1_idx = edge
        v0 = vertex_dict[v0_idx]['coords']
        v1 = vertex_dict[v1_idx]['coords']
        
        # 计算中点
        midpoint = (v0 + v1) / 2
        
        # 添加新顶点
        label = 1 if (vertex_dict[v0_idx]['label'] == 1 or vertex_dict[v1_idx]['label'] == 1) else 0
        new_vertices.append({'coords': midpoint, 'label': label})
        
        edge_midpoints[edge] = next_vertex_id
        next_vertex_id += 1
    
    print(f"  添加了 {len(edge_midpoints)} 个新顶点")
    
    # 细化四面体
    new_tetrahedra = []
    for tet in tetrahedra:
        sub_tets = refine_tetrahedron(tet, vertices, edge_midpoints, next_vertex_id)
        new_tetrahedra.extend(sub_tets)
    
    print(f"  四面体: {len(tetrahedra)} -> {len(new_tetrahedra)}")
    
    # 细化三角形（如果存在）
    new_triangles = []
    if triangles:
        for tri in triangles:
            sub_tris = refine_surface_triangle(tri, vertices, edge_midpoints, next_vertex_id)
            new_triangles.extend(sub_tris)
        print(f"  三角形: {len(triangles)} -> {len(new_triangles)}")
    
    print("网格细化完成!")
    
    return new_vertices, new_tetrahedra, new_triangles

def refine_mesh_uniform(input_file, output_file, refinement_levels=1):
    """均匀细化网格
    
    参数:
        input_file: 输入的.mesh文件
        output_file: 输出的.mesh文件
        refinement_levels: 细化级别（1次细化将四面体分为8个）
    """
    
    print(f"\n读取网格文件: {input_file}")
    vertices, tetrahedra, triangles = read_mesh_file(input_file)
    
    print(f"原始网格信息:")
    print(f"  顶点数: {len(vertices)}")
    print(f"  四面体数: {len(tetrahedra)}")
    print(f"  三角形数: {len(triangles)}")
    
    current_vertices = vertices
    current_tetrahedra = tetrahedra
    current_triangles = triangles
    
    for level in range(refinement_levels):
        print(f"\n--- 第 {level+1} 级细化 ---")
        current_vertices, current_tetrahedra, current_triangles = refine_mesh(
            current_vertices, current_tetrahedra, current_triangles
        )
    
    print(f"\n最终网格信息:")
    print(f"  顶点数: {len(current_vertices)}")
    print(f"  四面体数: {len(current_tetrahedra)}")
    print(f"  三角形数: {len(current_triangles)}")
    
    print(f"\n保存细化网格: {output_file}")
    write_mesh_file(output_file, current_vertices, current_tetrahedra, current_triangles)
    
    print("完成!")

def refine_mesh_adaptive(input_file, output_file, quality_threshold=0.01):
    """自适应细化网格（细化体积较大的四面体）
    
    参数:
        input_file: 输入的.mesh文件
        output_file: 输出的.mesh文件
        quality_threshold: 体积阈值，大于此值的四面体将被细化
    """
    
    def tetra_volume(v0, v1, v2, v3):
        return abs(np.dot(v1 - v0, np.cross(v2 - v0, v3 - v0))) / 6.0
    
    print(f"\n读取网格文件: {input_file}")
    vertices, tetrahedra, triangles = read_mesh_file(input_file)
    
    print(f"原始网格:")
    print(f"  顶点数: {len(vertices)}")
    print(f"  四面体数: {len(tetrahedra)}")
    
    # 计算每个四面体的体积
    vertex_coords = [v['coords'] for v in vertices]
    tet_volumes = []
    
    for tet in tetrahedra:
        v_idx = tet['indices']
        vol = tetra_volume(vertex_coords[v_idx[0]], vertex_coords[v_idx[1]],
                          vertex_coords[v_idx[2]], vertex_coords[v_idx[3]])
        tet_volumes.append(vol)
    
    avg_volume = np.mean(tet_volumes)
    print(f"  平均体积: {avg_volume:.6f}")
    print(f"  体积阈值: {quality_threshold:.6f}")
    
    # 找出需要细化的四面体
    to_refine = [i for i, vol in enumerate(tet_volumes) if vol > quality_threshold]
    print(f"  需要细化的四面体: {len(to_refine)}")
    
    if len(to_refine) == 0:
        print("没有需要细化的四面体")
        return
    
    # 收集需要细化的四面体的边
    edges_to_refine = set()
    for tet_idx in to_refine:
        indices = tetrahedra[tet_idx]['indices']
        for i in range(4):
            for j in range(i+1, 4):
                edges_to_refine.add(tuple(sorted([indices[i], indices[j]])))
    
    # 计算边的中点并添加新顶点
    vertex_dict = {i: v for i, v in enumerate(vertices)}
    edge_midpoints = {}
    new_vertices = copy.deepcopy(vertices)
    next_vertex_id = len(vertices)
    
    for edge in edges_to_refine:
        v0_idx, v1_idx = edge
        v0 = vertex_dict[v0_idx]['coords']
        v1 = vertex_dict[v1_idx]['coords']
        midpoint = (v0 + v1) / 2
        
        label = 1 if (vertex_dict[v0_idx]['label'] == 1 or vertex_dict[v1_idx]['label'] == 1) else 0
        new_vertices.append({'coords': midpoint, 'label': label})
        edge_midpoints[edge] = next_vertex_id
        next_vertex_id += 1
    
    # 细化选中的四面体
    new_tetrahedra = []
    for i, tet in enumerate(tetrahedra):
        if i in to_refine:
            sub_tets = refine_tetrahedron(tet, vertices, edge_midpoints, next_vertex_id)
            new_tetrahedra.extend(sub_tets)
        else:
            new_tetrahedra.append(tet)
    
    # 更新三角形表面（简化处理）
    new_triangles = triangles if triangles else []
    
    print(f"\n自适应细化后:")
    print(f"  顶点数: {len(new_vertices)} (+{len(new_vertices)-len(vertices)})")
    print(f"  四面体数: {len(new_tetrahedra)} (+{len(new_tetrahedra)-len(tetrahedra)})")
    
    print(f"\n保存细化网格: {output_file}")
    write_mesh_file(output_file, new_vertices, new_tetrahedra, new_triangles)
    print("完成!")

# ========== 使用示例 ==========

if __name__ == "__main__":
    # 示例1：均匀细化（每个四面体细分为8个）
    print("=" * 60)
    print("示例1: 均匀细化网格")
    print("=" * 60)
    
    # 假设已有 cylinder_1000.mesh 文件
    input_file = "../data/cyl248.mesh"
    output_file_uniform = "../data/cyl248_refine.mesh"
    
    try:
        refine_mesh_uniform(input_file, output_file_uniform, refinement_levels=1)
    except FileNotFoundError:
        print(f"文件 {input_file} 不存在，请先生成网格文件")
    
    # 示例2：自适应细化（细化大体积四面体）
    print("\n" + "=" * 60)
    print("示例2: 自适应细化网格")
    print("=" * 60)
    
    input_file = "../data/cyl248_refine.mesh"
    output_file_adaptive = "../data/cy248_refined_adaptive.mesh"
    
    try:
        refine_mesh_adaptive(input_file, output_file_adaptive, quality_threshold=0.01)
    except FileNotFoundError:
        print(f"文件 {input_file} 不存在，跳过自适应细化")
    
    # ; # 均匀细化一次
# ; refine_mesh_uniform("input.mesh", "output.mesh", refinement_levels=1)

# ; # 均匀细化两次（1个四面体 -> 64个）
# ; refine_mesh_uniform("input.mesh", "output.mesh", refinement_levels=2)

# ; # 自适应细化
# ; refine_mesh_adaptive("input.mesh", "output_adaptive.mesh", quality_threshold=0.01)
