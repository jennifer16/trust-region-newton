#  python3 ../myexperiments/armadillo_stretch/armadillo_stretch.py
import os
import sys

smooth_mode_strs = ["face","none"] # ["none","face", "default"]
diff = True
diff_mode_strs = ['abs_nondiff'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs '] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'

# proj_eps_list = ['-1', '0', '-0.5']
pr_list = ['0.495']
deform_scale_list = ['0.8']

mesh_name = 'armadillo'
experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
  # for proj_eps in proj_eps_list:
    for pr in pr_list:
      for deform_scale in deform_scale_list:
        try:
          command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
            + ' -l stretch_shear -g ' + deform_scale \
            + ' --ym 1e8 --pr ' + pr \
            + ' --experiment_name ' + experiment_name \
            + ' --tr 0.01' \
            + ' --diff' \
            + ' --diff_mode ' + diff_mode_str \
            + ' --smooth_mode ' + smooth_mode_str \
            + ' -b 0.2' 
          print(command)
          os.system(command)
        except:
          print('Error: ' + mesh_name)
