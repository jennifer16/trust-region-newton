import os
import sys

smooth_mode_strs = ["face","none"] # ["none","face", "default"]
diff = True
diff_mode_strs = ['abs_nondiff'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs '] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'

# proj_eps_list = ['-1', '0', '-0.5']
pr_list = ['0.1', '0.2', '0.3', '0.4', '0.45', '0.46', '0.47', '0.48', '0.49', '0.495', '0.499', '0.4999']
deform_scale_list = ['3.0']

mesh_name = 'cylinder'
experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
  # for proj_eps in proj_eps_list:
    for pr in pr_list:
      for deform_scale in deform_scale_list:
        try:
          command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
            + ' -l stretch_longest_axis -t ' + deform_scale \
            + ' --ym 1e8 --pr ' + pr \
            + ' --experiment_name ' + experiment_name \
            + ' --diff' \
            + ' --diff_mode ' + diff_mode_str \
            + ' --smooth_mode ' + smooth_mode_str \
            + ' --tr 0.01' 
          print(command)
          os.system(command)
        except:
          print('Error: ' + mesh_name)
