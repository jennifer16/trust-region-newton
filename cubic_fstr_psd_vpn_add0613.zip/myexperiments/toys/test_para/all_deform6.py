# 当前目录是 ~/Documents/fstr_psd/trust-region-newton/build
# python3 ../myexperiments/toys/all_deform.py

import sys, os

pre_str = 'python3 ../myexperiments/toys/'

# mesh_names = ['bar_1K' ]
mesh_names = {
   'stretch.py': ['bar_1K'],  # ['cyl248']
   # 'compress_percentage.py': ['bar_1K'], # ['cyl248','quad_2tets_3l']
   'compress_percentage.py': ['cube'], # ['cyl248','quad_4tets_3l','tri_prism_3l']
   # 'compress.py': ['bar_1K'], # ['cyl248']
   'twist.py': ['bar_1K'], # ['cyl248']
   'bend.py': ['bar_1K'],
   'shear_percentage.py': ['bar_1K'],
}

#diff_constraint = True  #

# commands = ['bend.py', 'compress.py','shear.py', 'stretch.py', 'twist.py','combined.py']
# commands = ['compress.py', 'bend.py','stretch.py', 'twist.py','shear.py']
# commands = [ 'bend.py', 'compress_percentage.py','shear_percentage.py','stretch.py','twist.py'] # for negative_ev


# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending'] # for negative_ev
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending','clamp_abs_blending2','clamp_abs_blending_smooth']
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending','clamp_abs_blending3','clamp_abs_blending4','clamp_abs_blending5']
# diff_mode_strs = ['clamp_abs_blending_shear','clamp_abs_blending','clamp_abs_nondiff']



# ok-config for  face + clamp,abs,clamp_abs / none + clamp,abs,clamp_abs
# commands = ['stretch.py', 'compress_percentage.py', 'bend.py','shear_percentage.py','twist.py']
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff']

commands = ['stretch.py', 'compress_percentage.py', 'bend.py','shear_percentage.py','twist.py'] # for negative_ev
diff_mode_strs = ['clamp_abs_blending_j'] # for negative_ev



smooth_mode_strs = ['none'] # ["none","face", "default"]
# pr_list = ['0.495','0.49','0.45','0.4','0.3']
pr_list = ['0.495']
# pr_list = ['0.495','0.3']
ym_list = ['1e8']
adaptive = '1'  # <= 0:[0 / 1] ; >0：[0 to 1]


# ============================= for var method ======================================
#  * pos_mode_strs
#  * case 1: 固定0.8,有eps   "better "
#  * case 2: 固定0.8,无eps    "better "
#  * case 3: 收缩程度受grad影响, 0.8-1.0  "better "
#  * case 0: 不收缩1.0,clamp(lambda) "good"
#  * case 4: hessian信息和梯度信息共同决定收缩程度，hessian主导，grad微调，0.8-1.0  "not good"
#  * case 5: hessian信息和梯度信息共同决定收缩程度，grad主导，hessian微调，0.8-1.0  "not good "

#  * neg_mode_strs
#  * case 0: 强收缩0.0，clamp(lambda),直接投影到m_eps                          "best"
#  * case 1: 收缩程度受grad影响, 0-1.0                                         "best"
#  * case 4: hessian信息和梯度信息共同决定收缩程度，grad主导，hessian微调，0.8-1.0  "best"
#  * case 2: 收缩程度受hessian影响, 0-1.0                                      "better"
#  * case 3: hessian信息和梯度信息共同决定收缩程度，hessian主导，grad微调，0.8-1.0  "better "
#  * case 5: 不收缩1.0,abs(lambda) "not good "
#  * case 6: hessian信息和梯度信息共同决定收缩程度，hessian主导，grad微调, J主导翻转

#  * gamma_strs
# 0: gamma = H_proj.norm()/(g.norm() + 1e-10); 
# -1: gamma = (g.norm()*g.norm())/(H_proj.norm() * H_proj.norm() * H_proj.norm() + 1e-10); 
# -2: gamma = (f)/(H_proj.norm() * H_proj.norm()  + 1e-10)
# other: fixed gamma value

#  * updateGamma
# 0: gamma = global_gamma; 
# 1: gamma = (j)^(1/3)/mu; 
# 2: gamma = (j)^(1/3)/mu * global_gamma
# other: fixed gamma value

# grad_mode
# 0: 区分safe direction 1/3次方 + unsafe direction 1/2次方; 
# 1: 区分，unsafe不同 safe direction 1/3次方 + unsafe direction, clamp到0.0; 
# 2: 区分，unsafe不同 safe direction 1/3次方  + unsafe direction with alpha_min
# 3: 区分，unsafe不同 safe direction 1/3次方 with alpha_min + unsafe direction with alpha_min
# 4: 不区分safe&unsafe


pos_mode_strs = ['1'] #['0','1','2','3','4','5']

#grad, eta, gamma, j->neg(safe/unsafe)
neg_mode_strs = ['1'] # 0:clamp 1: grad; 5: abs ['0','1','2','3','4','5','6','7','8','9','10']
grad_mode_strs = ['4'] # ['0','1','2','3','4']

# E->gamma
gamma_strs = ['-4'] # 2,4,  ['1', '0','-1','-2','-3','-4','-5','-6']
update_gamma_mode_strs = ['0'] # 0:gamma_str_global, 1:L/mu; 2:gamma_str_global * L/mu ['0','1','2']

#j ,kappa -> eta
j_mode_strs = ['0'] # 0:0.9，>0.9线性,<0 非线性 1: 安全因子; 2: <1.5 =0; <0 = 1,other =1 ;3: (J-0.9)^2 ['0','1','2','3']
kappa_mode_strs = ['0']  # 0: 1; 1:负特征值能量; 2:alpha_J ; 3. max(alpha_J, 负特征值能量) ['0','1','2','3']
eta_mode_strs = ['0'] # 0:fixed+same, 1:kappa+diff; 2:fixed+diff ['0','1','2']

##====================== simple test to scan grad_mode(3) ============================
pos_mode_strs = ['1'] # 固定0.8,有eps

neg_mode_strs = ['1'] # grad only
grad_mode_strs = ['3']  # 2: safe direction 1/3次方  + unsafe direction with alpha_min 3: safe direction 1/3次方 with alpha_min + unsafe direction with alpha_min

udpate_gamma_mode_strs = ['0','1','2'] # 1:L/mu, tbd?
gamma_strs = ['-1','-2','-8'] # global:-2,-4

eta_mode_strs = ['0'] # 0:fixed+same eta for alpha_min
# inactive
j_mode_strs = ['1']
kappa_mode_strs = ['0']   # for negative_ev

commands = ['stretch.py', 'compress_percentage.py', 'bend.py'] # for negative_ev
# commands = [ 'bend.py'] # for negative_ev 
 
for com in commands:
   os.system(pre_str+com+ ' --methods ' + ','.join(diff_mode_strs) + ' --meshes ' + ','.join(mesh_names[com]) + ' --pr ' + ','.join(pr_list) + ' --ym ' + ','.join(ym_list) + ' --adaptive ' + adaptive +' --smooth_modes ' + ','.join(smooth_mode_strs) + ' --para_gamma ' + ','.join(gamma_strs) + ' --para_pos_mode ' + ','.join(pos_mode_strs) + ' --para_neg_mode ' + ','.join(neg_mode_strs) + ' --para_j_mode ' + ','.join(j_mode_strs)+ ' --update_gamma_mode ' + ','.join(update_gamma_mode_strs)+ ' --eta_mode ' + ','.join(eta_mode_strs)+ ' --kappa_mode ' + ','.join(kappa_mode_strs) + ' --grad_mode ' + ','.join(grad_mode_strs) )