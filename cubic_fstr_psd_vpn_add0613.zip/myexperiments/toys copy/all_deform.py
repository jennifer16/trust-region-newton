# 当前目录是 ~/Documents/fstr_psd/trust-region-newton/build
# python3 ../myexperiments/toys/all_deform.py

import sys, os

pre_str = 'python3 ../myexperiments/toys/'

mesh_names = ['bar_1K' ]

# commands = ['bend.py', 'compress.py','shear.py', 'stretch.py', 'twist.py','combined.py']
# commands = ['compress.py', 'bend.py','stretch.py', 'twist.py','shear.py']
# diff_mode_strs = ['clamp_abs_blending_shear','clamp_abs_blending','clamp_abs_nondiff']

# commands = ['compress.py']
# diff_mode_strs = ['clamp_abs_blending']

# commands = ['compress.py']
# commands = [ 'compress.py','bend.py','stretch.py', 'twist.py','shear.py']
# commands = [ 'shear.py','bend.py', 'twist.py','compress.py','stretch.py']
# commands = ['stretch.py']
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending']

commands = [ 'shear_percentage.py','stretch.py','twist.py','bend.py', 'compress.py']
diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending','clamp_abs_blending_smooth']

# commands = ['shear.py']
# diff_mode_strs = ['clamp_abs_nondiff']


# pr_list = ['0.495','0.49','0.45','0.4','0.3']
pr_list = ['0.495','0.45']
# pr_list = ['0.495']
ym_list = ['1e8']
adaptive = '1'  # <= 0:[0 / 1] ; >0：[0 to 1]

for com in commands:
    os.system(pre_str+com+ ' --methods ' + ','.join(diff_mode_strs) + ' --meshes ' + ','.join(mesh_names) + ' --pr ' + ','.join(pr_list) + ' --ym ' + ','.join(ym_list) + ' --adaptive ' + adaptive)