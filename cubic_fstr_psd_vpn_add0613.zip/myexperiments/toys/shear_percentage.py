#  python3 ../myexperiments/toys/shear.py
import os
import sys

# 获取命令行参数
# sys.argv[0] 是脚本名称，sys.argv[1:] 是实际参数
args = sys.argv[1:]

# 1.methods
if len(args)>=2 and args[0] == '--methods':  
    diff_mode_strs = args[1].split(',') 
else:
    diff_mode_strs = ['clamp_abs_blending'] 
print(f"方法: {diff_mode_strs}")

# 2.mesh_names
if len(args)>=4 and args[2] == '--meshes':  
    mesh_names = args[3].split(',')
else:
    mesh_names = ['bar_1K' ]
print(f"模型: {mesh_names}")

# 3.pr
if len(args)>=6 and args[4] == '--pr':  
    pr_list = args[5].split(',')
else:
    pr_list = ['0.495']
print(f"pr: {pr_list}")

# 4.ym
if len(args)>=8 and args[6] == '--ym':  
    ym_list = args[7].split(',')
else:
    ym_list = ['1e8']
print(f"ym: {ym_list}")

# 5.adaptive
if len(args)>=10 and args[8] == '--adaptive':  
    adaptive = args[9]
else:
    adaptive = '-1'
print(f"adaptive: {adaptive}")

# 6.smooth_mode
if len(args)>=12 and args[10] == '--smooth_modes':  
    smooth_mode_strs = args[11].split(',')
else:
    smooth_mode_strs = ["none"]
print(f"smooth_modes: {smooth_mode_strs}")

# 7.gamma_mode
if len(args)>=14 and args[12] == '--para_gamma':  
    gamma_strs = args[13].split(',')
else:
    gamma_strs = ["none"]
print(f"gamma_strs: {gamma_strs}")

# 8.para_pos_mode
if len(args)>=16 and args[14] == '--para_pos_mode':  
    pos_mode_strs = args[15].split(',')
else:
    pos_mode_strs = ["none"]
print(f"pos_modes: {pos_mode_strs}")

# 9.para_neg_mode
if len(args)>=18 and args[16] == '--para_neg_mode':  
    neg_mode_strs = args[17].split(',')
else:
    neg_mode_strs = ["none"]
print(f"neg_modes: {neg_mode_strs}")

# 10.para_j_mode
if len(args)>=20 and args[18] == '--para_j_mode':  
    j_mode_strs = args[19].split(',')
else:
    j_mode_strs = ["none"]
print(f"j_modes: {j_mode_strs}")

# 11.update_gamma
if len(args)>=22 and args[20] == '--update_gamma_mode':  
    update_gamma_mode_strs = args[21].split(',')
else:
    update_gamma_mode_strs = ["none"]
print(f"update_gamma_mode_strs: {update_gamma_mode_strs}")

# 12.eta_mode_strs
if len(args)>=24 and args[22] == '--eta_mode':  
    eta_mode_strs = args[23].split(',')
else:
    eta_mode_strs = ["none"]
print(f"eta_mode_strs: {eta_mode_strs}")

# 13.kappa_mode_strs
if len(args)>=26 and args[24] == '--kappa_mode':  
    kappa_mode_strs = args[25].split(',')
else:
    kappa_mode_strs = ["none"]
print(f"kappa_mode_strs: {kappa_mode_strs}")

# 14.grad_mode_strs
if len(args)>=28 and args[26] == '--grad_mode':  
    grad_mode_strs = args[27].split(',')
else:
    grad_mode_strs = ["none"]
print(f"grad_mode_strs: {grad_mode_strs}")

# mesh_names = ['octopus_4K','bunny_6K','squirrel_7K','bar_1K','bar_2K','bar_4K','cube_3K', 'longbar_1.6K','cube_3K']
# mesh_names = ['bar_1K' ]

# smooth_mode_strs = ["none"] # ["none","face", "default"]
diff = True
# diff_mode_strs = ['clamp_abs_nondiff'] #['smooth_tr'] # 'blending' for trust region method
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending']
# diff_mode_strs = ['abs_shift_clamp_nondiff','clamp_abs_nondiff'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['cubic','clamp_abs_nondiff']
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs '] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'
# adaptive = '1'  # > 0:[0 or 1] ; <=0：[0 to 1]

# proj_eps_list = ['-1', '0', '-0.5']
# pr_list = ['0.495']
# ym_list = ['1e8']

# ['stretch_longest_axis','stretch_shear','stretch_twist_top','stretch_percentage','stretch_top','stretch_front','stretch',\
# 'stretch_shear_front','stretch_shear_longest_axis','stretch_shear_percentage'，\
# 'bend_stretch',\
# 'shear', 'shear_percentage','shear_top','shear_top_percentage'\
# 'compress','compress_percentage','compress_top','compress_longest_axis'\
# ]

# deform_scale_list = ['0.3','0.5','0.8','1.0','1.5', '2.0']#['0.3']

deform_styles = ['shear_top_percentage'] #['shear_top_percentage' 'shear_percentage']
# deform_scale_list = ['0.3','0.5','0.8','1.0','1.5', '2.0']#['0.3']

deform_scale_list = ['0.1','0.5','1.0','1.5', '2.0']#['0.3']
# deform_scale_list = ['0.3','1.0']#['0.3']


experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

# -t ratio
# -g for magnitude
for pos_mode_str in pos_mode_strs:
    for neg_mode_str in neg_mode_strs:
        for gamma_str in gamma_strs:
            for smooth_mode_str in smooth_mode_strs:
                for diff_mode_str in diff_mode_strs:
                # for proj_eps in proj_eps_list:
                    for pr in pr_list:
                        for ym in ym_list:
                            for deform_scale in deform_scale_list:
                                for mesh_name in mesh_names:
                                    for deform_style in deform_styles:
                                        for j_mode_str in j_mode_strs:
                                            for update_gamma_mode_str in update_gamma_mode_strs:
                                                for eta_mode_str in eta_mode_strs:
                                                    for kappa_mode_str in kappa_mode_strs:
                                                        for grad_mode_str in grad_mode_strs:
                                                            try:
                                                                command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
                                                                + ' -l '+ deform_style + ' -t ' + deform_scale  \
                                                                + ' --ym '+ ym + ' --pr ' + pr \
                                                                + ' --experiment_name ' + experiment_name \
                                                                + ' --diff' \
                                                                + ' --diff_mode ' + diff_mode_str \
                                                                + ' --smooth_mode ' + smooth_mode_str \
                                                                + ' --adaptive ' + adaptive \
                                                                + ' --para_gamma ' + gamma_str \
                                                                + ' --para_pos_mode ' + pos_mode_str \
                                                                + ' --para_neg_mode ' + neg_mode_str \
                                                                + ' --para_j_mode ' + j_mode_str \
                                                                + ' --update_gamma_mode ' + update_gamma_mode_str \
                                                                + ' --eta_mode ' + eta_mode_str \
                                                                + ' --kappa_mode ' + kappa_mode_str \
                                                                + ' --grad_mode ' + grad_mode_str \
                                                                + ' --tr 0.01' 
                                                                print(command)
                                                                os.system(command)
                                                            except:
                                                                print('Error: ' + mesh_name)



