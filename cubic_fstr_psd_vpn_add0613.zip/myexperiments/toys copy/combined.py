#  python3 ../myexperiments/toys/combined.py
import os
import sys

# 获取命令行参数
# sys.argv[0] 是脚本名称，sys.argv[1:] 是实际参数
args = sys.argv[1:]

# methods
if len(args)>=2 and args[0] == '--methods':  
    diff_mode_strs = args[1].split(',') 
else:
    diff_mode_strs = ['clamp_abs_blending'] 
print(f"方法: {diff_mode_strs}")

# mesh_names
if len(args)>=4 and args[2] == '--meshes':  
    mesh_names = args[3].split(',')
else:
    mesh_names = ['bar_1K' ]
print(f"模型: {mesh_names}")

# pr
if len(args)>=6 and args[4] == '--pr':  
    pr_list = args[5].split(',')
else:
    pr_list = ['0.495']
print(f"pr: {pr_list}")

# ym
if len(args)>=8 and args[6] == '--ym':  
    ym_list = args[7].split(',')
else:
    ym_list = ['1e8']
print(f"ym: {ym_list}")

# adaptive
if len(args)>=10 and args[8] == '--adaptive':  
    adaptive = args[9]
else:
    adaptive = '-1'
print(f"adaptive: {adaptive}")

# mesh_names = ['octopus_4K','bunny_6K','squirrel_7K','bar_1K','bar_2K','bar_4K','cube_3K', 'longbar_1.6K','cube_3K']
# mesh_names = ['bar_1K' ]

smooth_mode_strs = ["none"] # ["face","none"] ["none","face", "default"]
diff = True
# diff_mode_strs = ['clamp_abs_nondiff'] #['smooth_tr'] # 'blending' for trust region method
# diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending']
# diff_mode_strs = ['cubic','clamp_abs_nondiff'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs '] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'
adaptive = '0'  # 0:[0 or 1] ; 2.0：[0 to 1]

# proj_eps_list = ['-1', '0', '-0.5']
# pr_list = ['0.495']
# ym_list = ['1e8']
deform_scale_list = ['0.5']
deform_styles = ['stretch_shear_longest_axis']
# ['stretch_longest_axis','stretch_shear','stretch_twist_top','stretch_percentage','stretch_top','stretch_front','stretch',\
# 'stretch_shear_front','stretch_shear_longest_axis','stretch_shear_percentage'，\
# 'bend_stretch',\
# 'shear',\
# 'compress','compress_percentage','compress_top','compress_longest_axis'\
# ]


experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
  # for proj_eps in proj_eps_list:
    for pr in pr_list:
      for ym in ym_list:
        for deform_scale in deform_scale_list:
          for mesh_name in mesh_names:
            for deform_style in deform_styles:
              try:
                command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
                  + ' -l '+ deform_style + ' -t ' + deform_scale \
                  + ' --ym '+ ym + ' --pr ' + pr \
                  + ' --experiment_name ' + experiment_name \
                  + ' --diff' \
                  + ' --diff_mode ' + diff_mode_str \
                  + ' --smooth_mode ' + smooth_mode_str \
                  + ' --adaptive ' + adaptive \
                  + ' --tr 0.01' 
                print(command)
                os.system(command)
              except:
                print('Error: ' + mesh_name)
