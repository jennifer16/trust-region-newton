# python3 ../myexperiments/meshes/generate_mesh.py
import numpy as np

dataDir = "../data/"

def diagnose_and_fix_mesh(vertices, tetrahedra):
    """诊断并修复网格问题"""
    
    print("=== 诊断四面体网格 ===")
    
    # 1. 检查体积
    volumes = [compute_tetrahedron_volume(vertices, tet) for tet in tetrahedra]
    negative = sum(1 for v in volumes if v < 0)
    zero = sum(1 for v in volumes if abs(v) < 1e-12)
    
    print(f"负体积: {negative}/{len(tetrahedra)}")
    print(f"零体积: {zero}/{len(tetrahedra)}")
    
    # 2. 检查质量
    qualities = [compute_tetrahedron_quality(vertices, tet) for tet in tetrahedra]
    poor = sum(1 for q in qualities if q < 0.1)
    print(f"质量差(<0.1): {poor}/{len(tetrahedra)}")
    
    # 3. 诊断问题
    if negative > 0:
        print("\n问题: 存在倒置四面体")
        print("解决: 修正节点顺序")
        tetrahedra = [fix_tetrahedron_orientation(vertices, tet) for tet in tetrahedra]
    
    if zero > 0:
        print("\n问题: 存在退化四面体")
        print("解决: 移除退化单元")
        tetrahedra = [tet for tet in tetrahedra 
                     if abs(compute_tetrahedron_volume(vertices, tet)) > 1e-10]
    
    if poor > 0:
        print("\n问题: 网格质量差")
        print("解决: 进行网格优化")
        vertices = optimize_tetrahedral_mesh(vertices, tetrahedra)
    
    return vertices, tetrahedra

def write_mesh_file(filename, vertices, tetrahedra, triangles):
    """
    将网格写入Medit .mesh文件格式（MeshVersionFormatted 1）
    
    格式规范:
    - Dimension: 3 (三维)
    - Vertices: 节点坐标，最后一列为材质标记(通常为1)
    - Tetrahedra: 四面体单元，最后一列为材质标记(通常为1)
    - Triangles: 三角形面单元（用于边界显示），最后一列为材质标记(通常为1)
    """
    with open(filename, 'w') as f:
        f.write("MeshVersionFormatted 1\n")
        # f.write("\n")
        
        # 写入维度
        f.write("Dimension 3\n")
    
        # 写入顶点
        f.write("Vertices\n")
        f.write(f"{len(vertices)}\n")
        for v in vertices:
            f.write(f"{v[0]} {v[1]} {v[2]} {v[3]}\n")
        # f.write("\n")
        
        # 写入四面体
        if tetrahedra and len(tetrahedra) > 0:
            f.write("Tetrahedra\n")
            f.write(f"{len(tetrahedra)}\n")
            for tet in tetrahedra:
                f.write(f"{tet[0]} {tet[1]} {tet[2]} {tet[3]} {tet[4]}\n")
            # f.write("\n")
        
        # 写入三角形面
        if triangles and len(triangles) > 0:
            f.write("Triangles\n")
            f.write(f"{len(triangles)}\n")
            for tri in triangles:
                f.write(f"{tri[0]} {tri[1]} {tri[2]} {tri[3]}\n")
            # f.write("\n")
    
        f.write("Edges\n")
        f.write("0\n")
        f.write(" End\n")

def create_tri_prism_3tets_per_layer(num_layers, filename):
    """
    三棱柱网格 - 每层3个四面体（最佳方案）
    
    节点分布：每层3个节点（三角形顶点）
    四面体单元：每层之间3个四面体（完全填充）
    """
    vertices = []
    
    # 底面三角形顶点（等边三角形）
    base_points = [
        [0.0, 0.0, 0.0],    # 顶点0
        [1.0, 0.0, 0.0],    # 顶点1
        [0.5, 0.866, 0.0],  # 顶点2 (等边三角形)
    ]
    
    # 生成所有层节点
    for layer in range(num_layers + 1):
        z = float(layer)
        for bp in base_points:
            vertices.append([bp[0], bp[1], z, 1])
    
    # 节点索引映射（1-based）
    def idx(layer, local_idx):
        return layer * 3 + local_idx + 1
    
    tetrahedra = []
    for layer in range(num_layers):
        # 底层节点
        a = idx(layer, 0)   # 0
        b = idx(layer, 1)   # 1
        c = idx(layer, 2)   # 2
        
        # 顶层节点
        a1 = idx(layer + 1, 0)  # 3
        b1 = idx(layer + 1, 1)  # 4
        c1 = idx(layer + 1, 2)  # 5
        
        # 方法1：固定对角线分割（简单可靠）
        tetrahedra.extend([
            [a, b, c, c1, 1],   # 四面体1：底面 + 顶面一点
            [a, b, c1, a1, 1],  # 四面体2：侧面四面体
            [a, c, c1, a1, 1],  # 四面体3：侧面四面体
        ])
        
        # 验证：这3个四面体正好填满三棱柱
        
        # 可选：交替使用不同分割模式提高网格质量
        # if layer % 2 == 0:
        #     # 模式1：使用对角线 a-c1
        #     tetrahedra.extend([
        #         [a, b, c, c1, 1],
        #         [a, b, c1, a1, 1],
        #         [a, c, c1, a1, 1],
        #     ])
        # else:
        #     # 模式2：使用对角线 b-a1
        #     tetrahedra.extend([
        #         [a, b, c, a1, 1],
        #         [b, c, a1, b1, 1],
        #         [a, b, a1, b1, 1],
        #     ])
    
    # 生成三角形面（边界）
    triangles = []
    
    # 底面三角形
    b0 = idx(0, 0)
    b1 = idx(0, 1)
    b2 = idx(0, 2)
    triangles.append([b0, b1, b2, 1])
    
    # 顶面三角形
    t0 = idx(num_layers, 0)
    t1 = idx(num_layers, 1)
    t2 = idx(num_layers, 2)
    triangles.append([t0, t2, t1, 1])
    
    # 侧面（三个四边形面，每个分成2个三角形）
    for layer in range(num_layers):
        a = idx(layer, 0)
        b = idx(layer, 1)
        c = idx(layer, 2)
        a1 = idx(layer + 1, 0)
        b1 = idx(layer + 1, 1)
        c1 = idx(layer + 1, 2)
        
        # 侧面 ab-b1-a1
        triangles.append([a, b, b1, 1])
        triangles.append([a, b1, a1, 1])
        
        # 侧面 bc-c1-b1
        triangles.append([b, c, c1, 1])
        triangles.append([b, c1, b1, 1])
        
        # 侧面 ca-a1-c1
        triangles.append([c, a, a1, 1])
        triangles.append([c, a1, c1, 1])
    
    write_mesh_file(filename, vertices, tetrahedra, triangles)
    print(f"创建 {filename}: {num_layers}层, {len(vertices)}节点, {len(tetrahedra)}四面体, {len(triangles)}三角形")

def create_tri_prism_mesh(num_layers, filename):
    """
    创建三角形截面棱柱层网格（三棱柱分解为四面体）
    
    节点分布：每层3个节点（三角形顶点）
    四面体单元：每层之间3个四面体
    三角形面：外表面边界
    """
    vertices = []
    
    # 底面三角形顶点 (z=0)
    base_points = [
        [0.0, 0.0, 0.0],                    # 顶点0
        [1.0, 0.0, 0.0],                    # 顶点1
        [0.5, 0.8660254037844386, 0.0],    # 顶点2
    ]
    
    # 生成所有层节点
    for layer in range(num_layers + 1):
        z = float(layer)
        for bp in base_points:
            vertices.append([bp[0], bp[1], z, 1])
    
    # 构建节点索引映射（1-based）
    def idx(layer, local_idx):
        return layer * 3 + local_idx + 1
    
    # 生成四面体单元
    tetrahedra = []
    for layer in range(num_layers):
        b0 = idx(layer, 0)
        b1 = idx(layer, 1)
        b2 = idx(layer, 2)
        t0 = idx(layer + 1, 0)
        t1 = idx(layer + 1, 1)
        t2 = idx(layer + 1, 2)
        
        tetrahedra.append([b0, b1, b2, t0, 1])
        tetrahedra.append([b1, b2, t0, t1, 1])
        tetrahedra.append([b2, t0, t1, t2, 1])
    
    # 生成三角形面（边界）
    triangles = []
    
    # 底面（层0的三角形）
    triangles.append([idx(0, 0), idx(0, 1), idx(0, 2), 1])
    
    # 顶面（层num_layers的三角形）
    triangles.append([idx(num_layers, 0), idx(num_layers, 2), idx(num_layers, 1), 1])
    
    # 侧面（三个矩形面，每个分解为2个三角形）
    for layer in range(num_layers):
        b0 = idx(layer, 0)
        b1 = idx(layer, 1)
        b2 = idx(layer, 2)
        t0 = idx(layer + 1, 0)
        t1 = idx(layer + 1, 1)
        t2 = idx(layer + 1, 2)
        
        # 侧面0-1
        triangles.append([b0, b1, t1, 1])
        triangles.append([b0, t1, t0, 1])
        
        # 侧面1-2
        triangles.append([b1, b2, t2, 1])
        triangles.append([b1, t2, t1, 1])
        
        # 侧面2-0
        triangles.append([b2, b0, t0, 1])
        triangles.append([b2, t0, t2, 1])
    
    write_mesh_file(filename, vertices, tetrahedra, triangles)
    print(f"创建 {filename}: {num_layers}层, {len(vertices)}节点, {len(tetrahedra)}四面体, {len(triangles)}三角形")


def optimize_tetrahedral_mesh(vertices, tetrahedra):
    """
    优化四面体网格质量
    包括：节点光滑、拓扑优化、几何优化
    """
    import numpy as np
    
    max_iterations = 100
    for iteration in range(max_iterations):
        # 1. Laplacian smoothing
        vertices = laplacian_smoothing(vertices, tetrahedra)
        
        # 2. 检查质量
        qualities = [compute_tetrahedron_quality(vertices, tet) for tet in tetrahedra]
        min_quality = min(qualities)
        avg_quality = np.mean(qualities)
        
        print(f"Iter {iteration}: min quality = {min_quality:.4f}, avg = {avg_quality:.4f}")
        
        if min_quality > 0.2:
            break
    
    return vertices

def laplacian_smoothing(vertices, tetrahedra, iterations=10):
    """拉普拉斯光滑"""
    import numpy as np
    
    vertices = np.array([v[:3] for v in vertices])
    n_vertices = len(vertices)
    
    for _ in range(iterations):
        new_vertices = vertices.copy()
        
        for i in range(n_vertices):
            # 找到包含顶点i的所有四面体
            neighbors = set()
            for tet in tetrahedra:
                if i+1 in tet[:4]:
                    # 获取相邻顶点
                    for j in tet[:4]:
                        if j-1 != i:
                            neighbors.add(j-1)
            
            if neighbors:
                # 移动到邻居中心
                new_vertices[i] = np.mean([vertices[n] for n in neighbors], axis=0)
        
        vertices = new_vertices
    
    # 转换回原始格式
    return [[v[0], v[1], v[2], 1] for v in vertices]

def create_quad_prism_4tets(num_layers, filename):
    """推荐：每层4四面体，使用体对角线，无额外节点"""
    vertices = []
    
    # 可调整的四边形尺寸
    width, height = 10.0, 10.0
    base_points = [
        [0.0, 0.0, 0.0],
        [width, 0.0, 0.0],
        [width, height, 0.0],
        [0.0, height, 0.0],
    ]
    
    # 生成节点
    for layer in range(num_layers + 1):
        z = float(layer)
        for bp in base_points:
            vertices.append([bp[0], bp[1], z, 1])
    
    def idx(layer, local_idx):
        return layer * 4 + local_idx + 1
    
    tetrahedra = []
    for layer in range(num_layers):
        a, b, c, d = [idx(layer, i) for i in range(4)]
        a1, b1, c1, d1 = [idx(layer + 1, i) for i in range(4)]
        
        # 交替使用不同的体对角线提高网格质量
        if layer % 2 == 0:
            # 使用体对角线 a-c1
            tetrahedra.extend([
                [a, b, c, c1, 1],
                [a, c, d, c1, 1],
                [a, b, c1, a1, 1],
                [a, c1, c, a1, 1],
            ])
        else:
            # 使用体对角线 c-a1
            tetrahedra.extend([
                [c, d, a, a1, 1],
                [c, a, b, a1, 1],
                [c, a1, a, c1, 1],
                [c, d, a1, c1, 1],
            ])

    # diagnose_and_fix_mesh(vertices,tetrahedra)
    optimize_tetrahedral_mesh(vertices,tetrahedra)
    
    # 边界三角形生成（与原来相同）
    triangles = []
    # ... (边界生成代码)
    
    write_mesh_file(filename, vertices, tetrahedra, triangles)
    print(f"创建 {filename}: {num_layers}层, {len(vertices)}节点, {len(tetrahedra)}四面体")
    
    # 验证：每个棱柱层应有4个四面体
    assert len(tetrahedra) == num_layers * 4

# def create_quad_prism_2tets_fixed(filename, num_layers=1):
#     """
#     创建单个四棱柱网格（固定对角线，用于简单测试）
#     """
#     vertices = []
    
#     base_points = [
#         [0.0, 0.0, 0.0],
#         [1.0, 0.0, 0.0],
#         [1.0, 1.0, 0.0],
#         [0.0, 1.0, 0.0],
#     ]
    
#     for layer in range(2):
#         z = float(layer)
#         for bp in base_points:
#             vertices.append([bp[0], bp[1], z, 1])
    
#     def idx(layer, local_idx):
#         return layer * 4 + local_idx + 1
    
#     tetrahedra = [
#         [idx(0, 0), idx(0, 1), idx(0, 2), idx(1, 0), 1],
#         [idx(0, 0), idx(0, 2), idx(0, 3), idx(1, 2), 1],
#     ]
    
#     triangles = []
    
#     # 底面
#     triangles.append([idx(0, 0), idx(0, 1), idx(0, 2), 1])
#     triangles.append([idx(0, 0), idx(0, 2), idx(0, 3), 1])
    
#     # 顶面
#     triangles.append([idx(1, 0), idx(1, 2), idx(1, 1), 1])
#     triangles.append([idx(1, 0), idx(1, 3), idx(1, 2), 1])
    
#     # 侧面
#     for layer in range(1):
#         b0 = idx(layer, 0)
#         b1 = idx(layer, 1)
#         b2 = idx(layer, 2)
#         b3 = idx(layer, 3)
#         t0 = idx(layer + 1, 0)
#         t1 = idx(layer + 1, 1)
#         t2 = idx(layer + 1, 2)
#         t3 = idx(layer + 1, 3)
        
#         triangles.append([b0, b1, t1, 1])
#         triangles.append([b0, t1, t0, 1])
#         triangles.append([b1, b2, t2, 1])
#         triangles.append([b1, t2, t1, 1])
#         triangles.append([b2, b3, t3, 1])
#         triangles.append([b2, t3, t2, 1])
#         triangles.append([b3, b0, t0, 1])
#         triangles.append([b3, t0, t3, 1])
    
#     write_mesh_file(filename, vertices, tetrahedra, triangles)
#     print(f"创建 {filename}: {len(vertices)}节点, {len(tetrahedra)}四面体, {len(triangles)}三角形")


if __name__ == "__main__":
    print("=" * 60)
    print("生成三角形截面四面体网格（三棱柱）")
    print("=" * 60)
    for layers in [1, 2, 3, 4]:
        #create_tri_prism_mesh(layers, f"../data/tri_prism_{layers}l.mesh")
        create_tri_prism_3tets_per_layer(layers, f"../data/tri_prism_{layers}l.mesh")
    
    print("\n" + "=" * 60)
    print("生成四边形截面四面体网格（每层2个四面体）")
    print("=" * 60)
    
    # create_quad_prism_2tets_fixed("../data/quad_2tets_1l_fixed.mesh")
    
    for layers in [1, 2, 3, 4]:
        create_quad_prism_4tets(layers, f"../data/quad_4tets_{layers}l.mesh")
    
    print("\n" + "=" * 60)
    print("网格统计汇总")
    print("=" * 60)
    
    print("\n三角形截面（三棱柱）:")
    print("  层数 | 节点数 | 四面体数 | 三角形数 | 文件名")
    print("  -----|--------|---------|---------|-------------------")
    for layers in [1, 2, 3, 4]:
        nodes = (layers + 1) * 3
        tets = layers * 3
        tris = 2 + layers * 6
        print(f"  {layers}    | {nodes:6} | {tets:7} | {tris:7} | tri_prism_{layers}l.mesh")
    
    print("\n四边形截面（四棱柱，每层2个四面体）:")
    print("  层数 | 节点数 | 四面体数 | 三角形数 | 文件名")
    print("  -----|--------|---------|---------|-------------------")
    for layers in [1, 2, 3, 4]:
        nodes = (layers + 1) * 4
        tets = layers * 2
        tris = 4 + layers * 8
        print(f"  {layers}    | {nodes:6} | {tets:7} | {tris:7} | quad_2tets_{layers}l.mesh")
    
    print("\n固定对角线版本（四棱柱）:")
    print("  层数 | 节点数 | 四面体数 | 三角形数 | 文件名")
    print("  -----|--------|---------|---------|-------------------")
    print(f"  1    |      8 |       2 |      12 | quad_2tets_1l_fixed.mesh")
    
    print("\n所有.mesh文件已生成，格式为MeshVersionFormatted 1")
    print("可使用Medit、FreeFEM或meshio查看")