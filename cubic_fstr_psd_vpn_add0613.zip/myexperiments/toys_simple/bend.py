#  python3 ../myexperiments/toys_simple/bend.py
import os
import sys

# 获取命令行参数
# sys.argv[0] 是脚本名称，sys.argv[1:] 是实际参数
args = sys.argv[1:]

# 1.methods
if len(args)>=2 and args[0] == '--methods':  
    diff_mode_strs = args[1].split(',') 
else:
    diff_mode_strs = ['clamp_abs_blending'] 
print(f"方法: {diff_mode_strs}")

# 2.mesh_names
if len(args)>=4 and args[2] == '--meshes':  
    mesh_names = args[3].split(',')
else:
    mesh_names = ['bar_1K' ]
print(f"模型: {mesh_names}")

# 3.pr
if len(args)>=6 and args[4] == '--pr':  
    pr_list = args[5].split(',')
else:
    pr_list = ['0.495']
print(f"pr: {pr_list}")

# 4.ym
if len(args)>=8 and args[6] == '--ym':  
    ym_list = args[7].split(',')
else:
    ym_list = ['1e8']
print(f"ym: {ym_list}")

# 5.adaptive
if len(args)>=10 and args[8] == '--adaptive':  
    adaptive = args[9]
else:
    adaptive = '-1'
print(f"adaptive: {adaptive}")


# mesh_names = ['octopus_4K','bunny_6K','squirrel_7K','bar_1K','bar_2K','bar_4K','cube_3K', 'longbar_1.6K','cube_3K']

smooth_mode_strs = ["none"] # ["none","face", "default"]
diff = True
 #['smooth_tr'] # 'blending' for trust region method
#diff_mode_strs = ['clamp_nondiff','abs_nondiff','clamp_abs_nondiff','clamp_abs_blending']
# diff_mode_strs = ['clamp_abs_blending','clamp_abs_nondiff','cubic'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs ','cubic'] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'
# adaptive = '1'  # <= 0:[0 / 1] ; >0：[0 to 1]

# proj_eps_list = ['-1', '0', '-0.5']
# pr_list = ['0.495']
# ym_list = ['1e8']
# deform_scale_list = ['-0.7','-0.6','-0.5','-0.4','-0.3','-0.2','-0.1','0','0.1','0.2','0.3','0.4','0.5','0.6','0.7'] #['-0.02','0.1'] 

# ['stretch_longest_axis','stretch_shear','stretch_twist_top','stretch_percentage','stretch_top','stretch_front','stretch',\
# 'stretch_shear_front','stretch_shear_longest_axis','stretch_shear_percentage'，\
# 'bend_stretch', 'bend_rotate_ratio'\
# 'shear',\
# 'compress','compress_percentage','compress_top','compress_longest_axis'\
# ]

# deform_scale_list = ['0.2']

# rotate_ratio_list = ['0.1','0.25','0.4', '0.5','0.6', '0.75', '0.8',  '0.9','1.0'] # 0.1*180 degree rotation for bending
# deform_styles = ['bend_stretch']# 'bend_stretch', 'bend_rotate_ratio'
deform_styles = ['bend_stretch']# 'bend_stretch', 'bend_rotate_ratio'

# deform_scale_list = ['1.5']
deform_scale_list = ['2']
rotate_ratio_list = ['0.5'] # 0.1*180 degree rotation for bending


experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
  # for proj_eps in proj_eps_list:
    for pr in pr_list:
      for ym in ym_list:
        for deform_scale in deform_scale_list:
          for mesh_name in mesh_names:
            for deform_style in deform_styles:
              for rotate_ratio in rotate_ratio_list:
                try:
                  command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
                    + ' -l '+ deform_style + ' -t ' + deform_scale \
                    + ' --ym '+ ym + ' --pr ' + pr \
                    + ' --experiment_name ' + experiment_name \
                    + ' --diff' \
                    + ' --diff_mode ' + diff_mode_str \
                    + ' --smooth_mode ' + smooth_mode_str \
                    + ' --tr 0.01' \
                    + ' --adaptive ' + adaptive \
                    + ' --rotate_ratio ' + rotate_ratio
                  print(command)
                  os.system(command)
                except:
                  print('Error: ' + mesh_name)
