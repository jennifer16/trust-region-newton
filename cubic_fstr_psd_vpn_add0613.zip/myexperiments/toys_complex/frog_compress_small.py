# python3 ../myexperiments/teaser_frog/frog_compress_small.py
import os
import sys

# 获取命令行参数
# sys.argv[0] 是脚本名称，sys.argv[1:] 是实际参数
args = sys.argv[1:]

# 1.methods
if len(args)>=2 and args[0] == '--methods':  
    diff_mode_strs = args[1].split(',') 
else:
    diff_mode_strs = ['clamp_abs_blending'] 
print(f"方法: {diff_mode_strs}")

# 2.mesh_names
if len(args)>=4 and args[2] == '--meshes':  
    mesh_names = args[3].split(',')
else:
    mesh_names = ['cylinder' ]
print(f"模型: {mesh_names}")

# 3.ym
if len(args)>=6 and args[4] == '--ym':  
    ym_list = args[5].split(',')
else:
    ym_list = ['1e8']
print(f"ym: {ym_list}")

# 4.adaptive
if len(args)>=8 and args[6] == '--adaptive':  
    adaptive = args[7]
else:
    adaptive = '-1'
print(f"adaptive: {adaptive}")

smooth_mode_strs = ["none"] # ["none","face", "default"]
diff = True
# diff_mode_strs = ['abs_nondiff'] # 'clamp_abs_nondiff' for trust region method
# diff_mode_strs = ['clamp_abs_nondiff','abs_nondiff', 'clamp_nondiff','soft_clamp','soft_abs',
# 'clamp_abs', 'auto','hybrid','clamp','abs '] # 'clamp_abs_nondiff' for trust region method
proj_eps = '1e-7'

# proj_eps_list = ['-0.5', '-1', '0']
pr_list = ['0.495', '0.3']

deform_scale = '-0.2'
deform_label = 'stretch_shear_front'

mesh_name = 'frog'
experiment_name = 'figure_' + os.path.basename(__file__)[:-3]

for smooth_mode_str in smooth_mode_strs:
  for diff_mode_str in diff_mode_strs:
    for pr in pr_list:
      # for proj_eps in proj_eps_list:
        try:
          command = './example -p ' + proj_eps +  ' -n ' + mesh_name \
            + ' -l ' + deform_label + ' -g ' + deform_scale \
            + ' --ym 1e8 --pr ' + pr \
            + ' --experiment_name ' + experiment_name \
            + ' --tr 0.1' \
            + ' --diff' \
            + ' --diff_mode ' + diff_mode_str \
            + ' --smooth_mode ' + smooth_mode_str \
            + ' --adaptive ' + adaptive \
            + ' -b 0.2'
          print(command)
          os.system(command)
        except:
          print('Error: ' + mesh_name)